import javax.swing.*;
import java.net.URL;
import java.awt.geom.RoundRectangle2D;
import java.util.Calendar;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.Date;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.border.LineBorder;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import javax.swing.table.DefaultTableModel;
import java.io.*;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;
import javax.swing.border.TitledBorder;
import javax.imageio.ImageIO;
import javax.swing.filechooser.FileNameExtensionFilter;

// =========================================================================
// PET RELATED CLASSES
// =========================================================================

abstract class Pet {
    private final String petId;
    private final String name;
    private final LocalDate dob;
    private final int age;
    private final String breed;
    private final String healthStatus;
    private final boolean vaccinated;
    private final String imagePath;
    private final String notes;
    private final String type;
    private String status;

    public enum PetType { DOG, CAT, BIRD, RABBIT, FISH }

    protected Pet(String petId, String name, LocalDate dob, int age, String breed, String healthStatus, boolean vaccinated, String imagePath, String notes, String type) {
        this.petId = petId;
        this.name = name;
        this.dob = dob;
        this.age = age;
        this.breed = breed;
        this.healthStatus = healthStatus;
        this.vaccinated = vaccinated;
        this.imagePath = imagePath;
        this.notes = notes;
        this.type = type;
        this.status = "Available";
    }

    protected Pet(String petId, String name, LocalDate dob, int age, String breed, String healthStatus, boolean vaccinated, String imagePath, String notes, String type, String status) {
        this(petId, name, dob, age, breed, healthStatus, vaccinated, imagePath, notes, type);
        this.status = status;
    }

    public String getPetId() { return petId; }
    public String getName() { return name; }
    public LocalDate getDob() { return dob; }
    public int getAge() { return age; }
    public String getBreed() { return breed; }
    public String getHealthStatus() { return healthStatus; }
    public boolean isVaccinated() { return vaccinated; }
    public String getNotes() { return notes; }
    public String getType() { return type; }
    public String getImagePath() { return imagePath; }
    public String getStatus() { return status; }

    public void setStatus(String status) { this.status = status; }

    public abstract String getExtra();

    public String toCSV() {
        String safeNotes = (notes == null) ? "" : notes.replace(",", ";");
        String image = (imagePath == null) ? "" : imagePath;
        return String.join(",", petId, type, name, dob.toString(), String.valueOf(age), breed, getExtra(), healthStatus, vaccinated ? "Yes" : "No", image, safeNotes, status );
    }

    public static Pet fromCSV(String line) {
        String[] p = line.split(",", -1);
        if (p.length < 12) {
            System.err.println("Invalid CSV line format: " + line);
            return null;
        }
        String id = p[0], type = p[1], name = p[2];
        LocalDate dob = LocalDate.parse(p[3]);
        int age = Integer.parseInt(p[4]);
        String breed = p[5], extra = p[6], health = p[7];
        boolean vac = "Yes".equalsIgnoreCase(p[8]);
        String image = p[9], notes = p[10];
        String status = p[11];

        switch (type) {
            case "Dog": return new Dog(id, name, dob, age, breed, health, vac, image, notes, extra, status);
            case "Cat": return new Cat(id, name, dob, age, breed, health, vac, image, notes, status);
            case "Bird": return new Bird(id, name, dob, age, breed, health, vac, image, notes, status);
            case "Rabbit": return new Rabbit(id, name, dob, age, breed, health, vac, image, notes, status);
            case "Fish": return new Fish(id, name, dob, age, breed, health, vac, image, notes, status);
            default: return null;
        }
    }
}

class Dog extends Pet {
    private final String size;
    public Dog(String petId, String name, LocalDate dob, int age, String breed, String healthStatus, boolean vaccinated, String imagePath, String notes, String size) {
        super(petId, name, dob, age, breed, healthStatus, vaccinated, imagePath, notes, "Dog");
        this.size = size == null || size.isEmpty() ? "N/A" : size;
    }
    public Dog(String petId, String name, LocalDate dob, int age, String breed, String healthStatus, boolean vaccinated, String imagePath, String notes, String size, String status) {
        super(petId, name, dob, age, breed, healthStatus, vaccinated, imagePath, notes, "Dog", status);
        this.size = size == null || size.isEmpty() ? "N/A" : size;
    }
    @Override public String getExtra() { return size; }
    public String getSize() { return size; }
}

class Cat extends Pet {
    public Cat(String petId, String name, LocalDate dob, int age, String breed, String healthStatus, boolean vaccinated, String imagePath, String notes) {
        super(petId, name, dob, age, breed, healthStatus, vaccinated, imagePath, notes, "Cat");
    }
    public Cat(String petId, String name, LocalDate dob, int age, String breed, String healthStatus, boolean vaccinated, String imagePath, String notes, String status) {
        super(petId, name, dob, age, breed, healthStatus, vaccinated, imagePath, notes, "Cat", status);
    }
    @Override public String getExtra() { return "N/A"; }
}

class Bird extends Pet {
    public Bird(String petId, String name, LocalDate dob, int age, String breed, String healthStatus, boolean vaccinated, String imagePath, String notes) {
        super(petId, name, dob, age, breed, healthStatus, vaccinated, imagePath, notes, "Bird");
    }
    public Bird(String petId, String name, LocalDate dob, int age, String breed, String healthStatus, boolean vaccinated, String imagePath, String notes, String status) {
        super(petId, name, dob, age, breed, healthStatus, vaccinated, imagePath, notes, "Bird", status);
    }
    @Override public String getExtra() { return "N/A"; }
}

class Rabbit extends Pet {
    public Rabbit(String petId, String name, LocalDate dob, int age, String breed, String healthStatus, boolean vaccinated, String imagePath, String notes) {
        super(petId, name, dob, age, breed, healthStatus, vaccinated, imagePath, notes, "Rabbit");
    }
    public Rabbit(String petId, String name, LocalDate dob, int age, String breed, String healthStatus, boolean vaccinated, String imagePath, String notes, String status) {
        super(petId, name, dob, age, breed, healthStatus, vaccinated, imagePath, notes, "Rabbit", status);
    }
    @Override public String getExtra() { return "N/A"; }
}

class Fish extends Pet {
    public Fish(String petId, String name, LocalDate dob, int age, String breed, String healthStatus, boolean vaccinated, String imagePath, String notes) {
        super(petId, name, dob, age, breed, healthStatus, vaccinated, imagePath, notes, "Fish");
    }
    public Fish(String petId, String name, LocalDate dob, int age, String breed, String healthStatus, boolean vaccinated, String imagePath, String notes, String status) {
        super(petId, name, dob, age, breed, healthStatus, vaccinated, imagePath, notes, "Fish", status);
    }
    @Override public String getExtra() { return "N/A"; }
}

// =========================================================================
// FILE MANAGER
// =========================================================================

class FileManager {
    private static final String PET_FILE = "view_pets.txt";

    public static synchronized void savePet(Pet pet) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(PET_FILE, true))) {
            bw.write(pet.toCSV());
            bw.newLine();
        }
    }

    public static synchronized void overwritePetsFile(List<Pet> petsToSave) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(PET_FILE, false))) {
            for (Pet pet : petsToSave) {
                bw.write(pet.toCSV());
                bw.newLine();
            }
        }
    }

    public static synchronized List<Pet> readPets() {
        List<Pet> list = new ArrayList<>();
        File f = new File(PET_FILE);
        if (!f.exists()) return list;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String ln;
            while ((ln = br.readLine()) != null) {
                Pet p = Pet.fromCSV(ln);
                if (p != null) list.add(p);
            }
        } catch (Exception ex) {
            System.err.println("Error reading pets.txt: " + ex.getMessage());
        }
        return list;
    }

    public static synchronized String generateAutoId(String type) {
        List<Pet> pets = readPets();
        int max = 0;
        String prefix = type.toUpperCase().substring(0, Math.min(3, type.length()));

        for (Pet p : pets) {
            if (p.getType().equalsIgnoreCase(type)) {
                String id = p.getPetId();
                if (id != null && id.startsWith(prefix + "-")) {
                    try {
                        int num = Integer.parseInt(id.substring(prefix.length() + 1));
                        max = Math.max(max, num);
                    } catch (NumberFormatException ignored) {}
                }
            }
        }
        return String.format("%s-%03d", prefix, max + 1);
    }

    public static synchronized boolean isDuplicate(Pet pet) {
        for (Pet p : readPets()) {
            if (p.getName().equalsIgnoreCase(pet.getName()) && p.getType().equalsIgnoreCase(pet.getType()))
                return true;
        }
        return false;
    }

    public static Map<String, Integer> countByType() {
        Map<String, Integer> m = new HashMap<>();
        m.put("Total", 0);
        m.put("Dog", 0);
        m.put("Cat", 0);
        m.put("Bird", 0);
        m.put("Rabbit", 0);
        m.put("Fish", 0);

        for (Pet p : readPets()) {
            m.put("Total", m.get("Total") + 1);
            m.put(p.getType(), m.getOrDefault(p.getType(), 0) + 1);
        }
        return m;
    }
}

// =========================================================================
// JSON FILE MANAGER FOR PETS
// =========================================================================

class JsonFileManager {
    private static final String PETS_JSON_FILE = "pets_data.json";
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public static synchronized void savePetsToJson(List<Pet> pets) throws IOException {
        try (FileWriter writer = new FileWriter(PETS_JSON_FILE)) {
            List<Map<String, Object>> jsonPets = convertPetsToJsonFormat(pets);
            gson.toJson(jsonPets, writer);
            System.out.println("Pets data saved successfully to " + PETS_JSON_FILE);
        } catch (IOException e) {
            System.err.println("Error saving pets to JSON: " + e.getMessage());
            throw e;
        }
    }

    public static synchronized List<Pet> loadPetsFromJson() {
        File file = new File(PETS_JSON_FILE);
        if (!file.exists()) {
            System.out.println("Pets JSON file not found, returning empty list");
            return new ArrayList<>();
        }

        try (FileReader reader = new FileReader(PETS_JSON_FILE)) {
            Type listType = new TypeToken<List<Map<String, Object>>>(){}.getType();
            List<Map<String, Object>> jsonPets = gson.fromJson(reader, listType);

            if (jsonPets == null) {
                System.out.println("JSON file is empty or invalid, returning empty list");
                return new ArrayList<>();
            }

            List<Pet> pets = new ArrayList<>();
            for (Map<String, Object> petMap : jsonPets) {
                try {
                    Pet pet = convertJsonToPet(petMap);
                    if (pet != null) {
                        pets.add(pet);
                    }
                } catch (Exception e) {
                    System.err.println("Error converting JSON object to Pet: " + e.getMessage());
                }
            }

            System.out.println("Loaded " + pets.size() + " pets from " + PETS_JSON_FILE);
            return pets;
        } catch (IOException e) {
            System.err.println("Error loading pets from JSON: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    private static List<Map<String, Object>> convertPetsToJsonFormat(List<Pet> pets) {
        List<Map<String, Object>> jsonPets = new ArrayList<>();
        for (Pet pet : pets) {
            Map<String, Object> petMap = new HashMap<>();
            petMap.put("petId", pet.getPetId());
            petMap.put("name", pet.getName());
            petMap.put("type", pet.getType());
            petMap.put("dob", pet.getDob().toString());
            petMap.put("age", pet.getAge());
            petMap.put("breed", pet.getBreed());
            petMap.put("healthStatus", pet.getHealthStatus());
            petMap.put("vaccinated", pet.isVaccinated());
            petMap.put("imagePath", pet.getImagePath() != null ? pet.getImagePath() : "");
            petMap.put("notes", pet.getNotes() != null ? pet.getNotes() : "");
            petMap.put("status", pet.getStatus());

            if (pet instanceof Dog) {
                petMap.put("size", ((Dog) pet).getSize());
            }

            jsonPets.add(petMap);
        }
        return jsonPets;
    }

    private static Pet convertJsonToPet(Map<String, Object> petMap) {
        try {
            String petId = (String) petMap.get("petId");
            String name = (String) petMap.get("name");
            String type = (String) petMap.get("type");
            LocalDate dob = LocalDate.parse((String) petMap.get("dob"));

            Object ageObj = petMap.get("age");
            int age;
            if (ageObj instanceof Double) {
                age = ((Double) ageObj).intValue();
            } else {
                age = ((Integer) ageObj);
            }

            String breed = (String) petMap.get("breed");
            String healthStatus = (String) petMap.get("healthStatus");
            boolean vaccinated = (Boolean) petMap.get("vaccinated");
            String imagePath = (String) petMap.get("imagePath");
            String notes = (String) petMap.get("notes");
            String status = (String) petMap.get("status");

            switch (type) {
                case "Dog":
                    String size = (String) petMap.get("size");
                    return new Dog(petId, name, dob, age, breed, healthStatus, vaccinated, imagePath, notes, size, status);
                case "Cat":
                    return new Cat(petId, name, dob, age, breed, healthStatus, vaccinated, imagePath, notes, status);
                case "Bird":
                    return new Bird(petId, name, dob, age, breed, healthStatus, vaccinated, imagePath, notes, status);
                case "Rabbit":
                    return new Rabbit(petId, name, dob, age, breed, healthStatus, vaccinated, imagePath, notes, status);
                case "Fish":
                    return new Fish(petId, name, dob, age, breed, healthStatus, vaccinated, imagePath, notes, status);
                default:
                    return null;
            }
        } catch (Exception e) {
            System.err.println("Error converting JSON to Pet: " + e.getMessage());
            return null;
        }
    }
}
class PetManager {
    private static List<Pet> pets;
    private static boolean useJson = true;

    static {
        loadAllPets();
        if (pets.isEmpty()) {
            loadSamplePets();
        }
    }

    public static void loadAllPets() {
        if (useJson) {
            pets = JsonFileManager.loadPetsFromJson();
        } else {
            pets = FileManager.readPets();
        }
    }

    private static void loadSamplePets() {
        try {
            System.out.println("Loading sample pets data...");
            List<Pet> samplePets = new ArrayList<>();

            // Birds
            samplePets.add(new Bird("BIR-001", "Sky", LocalDate.of(2023, 5, 10), 1, "Canary", "Healthy", false, "/images/ViewPet1_RedCanaryBird.jpg", "Loves to whistle", "Available"));
            samplePets.add(new Bird("BIR-002", "Feather", LocalDate.of(2022, 9, 10), 2, "Parrot", "Healthy", false, "/images/ViewPet6_ParrotBird.jpg", "Soft voice", "Available"));
            samplePets.add(new Bird("BIR-003", "Whistle", LocalDate.of(2023, 1, 15), 1, "Finch", "Healthy", false, "/images/ViewPet11_GouldianfinchBird.jpg", "Bright feathers", "Available"));

            // Cats
            samplePets.add(new Cat("CAT-001", "Marble", LocalDate.of(2022, 6, 12), 2, "Persian", "Healthy", true, "/images/ViewPet2_PersianCat.jpg", "Very playful", "Available"));
            samplePets.add(new Cat("CAT-002", "Minty", LocalDate.of(2021, 7, 19), 3, "Maine Coon", "Healthy", true, "/images/ViewPet7_MaineCoonCat.jpg", "Calm personality", "Available"));
            samplePets.add(new Cat("CAT-003", "Snowpaw", LocalDate.of(2022, 2, 10), 2, "Bengal", "Healthy", true, "/images/ViewPet12_BengalCat.jpg", "Very fluffy", "Available"));

            // Fish
            samplePets.add(new Fish("FIS-001", "Bubbles", LocalDate.of(2023, 3, 1), 1, "Betta", "Healthy", false, "/images/ViewPet3_BettaFish.jpg", "Fast swimmer", "Available"));
            samplePets.add(new Fish("FIS-002", "Nemo", LocalDate.of(2023, 4, 5), 1, "Goldfish", "Healthy", false, "/images/ViewPet8_GoldFish.png", "Bright colors", "Available"));
            samplePets.add(new Fish("FIS-003", "Coral", LocalDate.of(2023, 9, 12), 1, "Betta", "Healthy", false, "/images/ViewPet13_BettaFish.jpg", "Colorful fins", "Available"));

            // Rabbits
            samplePets.add(new Rabbit("RAB-001", "Berry", LocalDate.of(2023, 2, 15), 1, "Lionhead", "Healthy", false, "/images/ViewPet4_LionHeadRabbit.jpg", "Shy but cute", "Available"));
            samplePets.add(new Rabbit("RAB-002", "Snowbell", LocalDate.of(2022, 1, 11), 2, "Mini Lop", "Healthy", true, "/images/ViewPet9_MinilopRabbit.jpg", "Very fluffy", "Available"));
            samplePets.add(new Rabbit("RAB-003", "Hopster", LocalDate.of(2023, 3, 20), 1, "Netherland Dwarf", "Healthy", false, "/images/ViewPet14_NetherlandDwarfRabbit.jpg", "Jumps a lot", "Available"));

            // Dogs
            samplePets.add(new Dog("DOG-001", "Cooper", LocalDate.of(2021, 4, 21), 3, "Husky", "Healthy", true, "/images/ViewPet5_HuskyDog.jpg", "Short and adorable", "Large", "Available"));
            samplePets.add(new Dog("DOG-002", "Rusty", LocalDate.of(2020, 8, 9), 4, "Labrador", "Healthy", true, "/images/ViewPet10_LabradorGoldenRetrieverDog.jpg", "Very smart", "Large", "Available"));
            samplePets.add(new Dog("DOG-003", "Buddy", LocalDate.of(2020, 4, 5), 4, "Beagle", "Healthy", true, "/images/ViewPet15_BeagleDog.jpg", "Friendly nature", "Medium", "Available"));

            pets = samplePets;
            JsonFileManager.savePetsToJson(pets);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static List<Pet> getAllPets() {
        return new ArrayList<>(pets);
    }

    public static void addPet(Pet pet) throws IOException {
        System.out.println("Adding new pet: " + pet.getName() + " (" + pet.getPetId() + ")");
        pets.add(pet); // Add to memory list immediately

        if (useJson) {
            JsonFileManager.savePetsToJson(pets);
        } else {
            FileManager.savePet(pet);
        }
    }

    public static void updatePetStatus(String petId, String newStatus) {
        boolean updated = false;
        for (Pet pet : pets) {
            if (pet.getPetId().equals(petId)) {
                pet.setStatus(newStatus);
                updated = true;
                break;
            }
        }
        if (updated) {
            try {
                if (useJson) {
                    JsonFileManager.savePetsToJson(pets);
                } else {
                    FileManager.overwritePetsFile(pets);
                }
            } catch (IOException e) {
                System.err.println("Error updating pet status: " + e.getMessage());
            }
        }
    }

    public static Pet getPetById(String petId) {
        for (Pet pet : pets) {
            if (pet.getPetId().equals(petId)) return pet;
        }
        return null;
    }

    public static Pet getPetByName(String petName) {
        for (Pet pet : pets) {
            if (pet.getName().equalsIgnoreCase(petName)) return pet;
        }
        return null;
    }

    public static synchronized String generateAutoId(String type) {
        String prefix;
        if (type.equalsIgnoreCase("Dog")) prefix = "DOG";
        else if (type.equalsIgnoreCase("Cat")) prefix = "CAT";
        else if (type.equalsIgnoreCase("Bird")) prefix = "BIR";
        else if (type.equalsIgnoreCase("Rabbit")) prefix = "RAB";
        else if (type.equalsIgnoreCase("Fish")) prefix = "FIS";
        else prefix = type.toUpperCase().substring(0, Math.min(3, type.length()));

        int maxId = 0;

        // Check all loaded pets to find the highest ID for this type
        for (Pet p : pets) {
            if (p.getType().equalsIgnoreCase(type)) {
                String id = p.getPetId();
                if (id != null && id.startsWith(prefix + "-")) {
                    try {
                        String numberPart = id.substring(prefix.length() + 1);
                        int num = Integer.parseInt(numberPart);
                        if (num > maxId) maxId = num;
                    } catch (NumberFormatException ignored) {}
                }
            }
        }
        return String.format("%s-%03d", prefix, maxId + 1);
    }

    public static boolean isDuplicate(Pet pet) {
        return FileManager.isDuplicate(pet);
    }

    public static Map<String, Integer> countByType() {
        return FileManager.countByType();
    }

    public static boolean deletePet(String petId) {
        boolean removed = pets.removeIf(pet -> pet.getPetId().equals(petId));
        if (removed) {
            try {
                if (useJson) {
                    JsonFileManager.savePetsToJson(pets);
                } else {
                    FileManager.overwritePetsFile(pets);
                }
            } catch (IOException e) {
                System.err.println("Error deleting pet: " + e.getMessage());
            }
        }
        return removed;
    }

    public static void setUseJson(boolean useJson) {
        PetManager.useJson = useJson;
        loadAllPets();
    }
}

// =========================================================================
// DATA PERSISTENCE MANAGER
// =========================================================================

class DataPersistenceManager {
    private static final String ADOPTION_RECORDS_FILE = "adoption_records.json";
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public static void saveAdoptionRecords(List<AdoptionRecord> records) {
        try (FileWriter writer = new FileWriter(ADOPTION_RECORDS_FILE)) {
            gson.toJson(records, writer);
            System.out.println("Adoption records saved successfully to " + ADOPTION_RECORDS_FILE);
        } catch (IOException e) {
            System.err.println("Error saving adoption records: " + e.getMessage());
        }
    }

    public static List<AdoptionRecord> loadAdoptionRecords() {
        File file = new File(ADOPTION_RECORDS_FILE);
        if (!file.exists()) {
            System.out.println("Adoption records file not found, returning default data");
            return getDefaultAdoptionRecords();
        }

        try (FileReader reader = new FileReader(ADOPTION_RECORDS_FILE)) {
            Type listType = new TypeToken<List<AdoptionRecord>>(){}.getType();
            List<AdoptionRecord> records = gson.fromJson(reader, listType);

            if (records != null && !records.isEmpty()) {
                int maxId = 0;
                for (AdoptionRecord record : records) {
                    try {
                        int currentId = Integer.parseInt(record.getRecordId().substring(1));
                        if (currentId > maxId) maxId = currentId;
                    } catch (NumberFormatException e) {
                        System.err.println("Invalid record ID format: " + record.getRecordId());
                    }
                }
                AdoptionRecord.setNextId(maxId + 1);
            }

            System.out.println("Adoption records loaded successfully from " + ADOPTION_RECORDS_FILE);
            return records != null ? records : getDefaultAdoptionRecords();
        } catch (IOException e) {
            System.err.println("Error loading adoption records: " + e.getMessage());
            return getDefaultAdoptionRecords();
        }
    }

    private static List<AdoptionRecord> getDefaultAdoptionRecords() {
        List<AdoptionRecord> defaultRecords = new ArrayList<>();
        saveAdoptionRecords(defaultRecords);
        return defaultRecords;
    }
}

// =========================================================================
// WRAP LAYOUT
// =========================================================================

class WrapLayout extends FlowLayout {
    public WrapLayout() {
        super();
    }

    public WrapLayout(int align) {
        super(align);
    }

    public WrapLayout(int align, int hgap, int vgap) {
        super(align, hgap, vgap);
    }

    @Override
    public Dimension preferredLayoutSize(Container target) {
        return layoutSize(target, true);
    }

    @Override
    public Dimension minimumLayoutSize(Container target) {
        Dimension minimum = layoutSize(target, false);
        minimum.width -= (getHgap() + 1);
        return minimum;
    }

    private Dimension layoutSize(Container target, boolean preferred) {
        synchronized (target.getTreeLock()) {
            int targetWidth = target.getSize().width;
            if (targetWidth == 0) {
                targetWidth = Integer.MAX_VALUE;
            }

            int hgap = getHgap();
            int vgap = getVgap();
            Insets insets = target.getInsets();
            int horizontalInsetsAndGap = insets.left + insets.right + (hgap * 2);
            int verticalInsetsAndGap = insets.top + insets.bottom + (vgap * 2);
            int maxWidth = targetWidth - horizontalInsetsAndGap;

            Dimension dim = new Dimension(0, 0);
            int rowWidth = 0;
            int rowHeight = 0;

            int nMembers = target.getComponentCount();

            for (int i = 0; i < nMembers; i++) {
                Component m = target.getComponent(i);
                if (m.isVisible()) {
                    Dimension d = preferred ? m.getPreferredSize() : m.getMinimumSize();

                    if (rowWidth + d.width > maxWidth) {
                        dim.width = Math.max(dim.width, rowWidth);
                        dim.height += rowHeight + vgap;
                        rowWidth = d.width + hgap;
                        rowHeight = d.height;
                    } else {
                        if (rowWidth > 0) {
                            rowWidth += hgap;
                        }
                        rowWidth += d.width;
                        rowHeight = Math.max(rowHeight, d.height);
                    }
                }
            }

            dim.width = Math.max(dim.width, rowWidth);
            dim.height += rowHeight;

            dim.width += horizontalInsetsAndGap;
            dim.height += verticalInsetsAndGap;

            return dim;
        }
    }
}

// =========================================================================
// GRADIENT PANEL
// =========================================================================

class GradientPanel extends JPanel {
    private Color startColor;
    private Color endColor;

    public GradientPanel(Color startColor, Color endColor) {
        this.startColor = startColor;
        this.endColor = endColor;
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        int w = getWidth();
        int h = getHeight();

        GradientPaint gp = new GradientPaint(0, 0, startColor, 0, h, endColor);
        g2d.setPaint(gp);
        g2d.fillRect(0, 0, w, h);

        g2d.dispose();
    }
}

// =========================================================================
// SHADOW PANEL
// =========================================================================

class ShadowPanel extends JPanel {
    private int shadowSize = 25;
    private Color shadowColor = new Color(0, 0, 0, 80);
    private int borderRadius = 35;

    public ShadowPanel() {
        super();
        setOpaque(false);
    }

    public ShadowPanel(LayoutManager layout) {
        super(layout);
        setOpaque(false);
    }

    public void setShadowSize(int shadowSize) {
        this.shadowSize = shadowSize;
        repaint();
    }

    public void setShadowColor(Color shadowColor) {
        this.shadowColor = shadowColor;
        repaint();
    }

    public void setBorderRadius(int borderRadius) {
        this.borderRadius = borderRadius;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        int width = getWidth();
        int height = getHeight();

        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);

        RoundRectangle2D shadowShape = new RoundRectangle2D.Double(
                shadowSize / 2.0, shadowSize / 2.0,
                width - shadowSize, height - shadowSize,
                borderRadius, borderRadius
        );

        g2d.setColor(shadowColor);
        g2d.fill(shadowShape);

        RoundRectangle2D panelShape = new RoundRectangle2D.Double(
                shadowSize / 2.0, shadowSize / 2.0,
                width - shadowSize, height - shadowSize,
                borderRadius, borderRadius
        );

        g2d.setColor(getBackground());
        g2d.fill(panelShape);

        g2d.dispose();
        super.paintComponent(g);
    }

    @Override
    public Insets getInsets() {
        int inset = shadowSize / 2 + 10;
        return new Insets(inset, inset, inset, inset);
    }

    @Override
    protected void paintBorder(Graphics g) {
    }
}

// =========================================================================
// HERO PANEL
// =========================================================================

class HeroPanel extends JPanel {
    private Image backgroundImage;
    private Color overlayColor = new Color(0, 0, 0, 120);

    public HeroPanel(String imagePath) {
        try {
            URL imgURL = getClass().getResource(imagePath);
            if (imgURL != null) {
                backgroundImage = new ImageIcon(imgURL).getImage();
                System.out.println("Hero background image loaded from classpath: " + imagePath);
            } else {
                System.err.println("Error: Hero background image not found at " + imagePath + " in classpath. Using fallback color.");
                setBackground(new Color(60, 60, 60));
            }
        } catch (Exception e) {
            System.err.println("Critical Error loading hero background image: " + e.getMessage());
            setBackground(new Color(60, 60, 60));
        }
        setLayout(new GridBagLayout());
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (backgroundImage != null) {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);

            int panelWidth = getWidth();
            int panelHeight = getHeight();

            int imageWidth = backgroundImage.getWidth(this);
            int imageHeight = backgroundImage.getHeight(this);

            if (imageWidth <= 0 || imageHeight <= 0) {
                System.err.println("Error: Background image has invalid dimensions or failed to decode. Using fallback color.");
                g2d.setColor(getBackground());
                g2d.fillRect(0, 0, panelWidth, panelHeight);
            } else {
                double scaleX = (double) panelWidth / imageWidth;
                double scaleY = (double) panelHeight / imageHeight;
                double scale = Math.max(scaleX, scaleY);

                int scaledWidth = (int) (imageWidth * scale);
                int scaledHeight = (int) (imageHeight * scale);

                int x = (panelWidth - scaledWidth) / 2;
                int y = (panelHeight - scaledHeight) / 2;

                g2d.drawImage(backgroundImage, x, y, scaledWidth, scaledHeight, this);
            }

            g2d.setColor(overlayColor);
            g2d.fillRect(0, 0, panelWidth, panelHeight);

            g2d.dispose();
        } else {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setColor(getBackground());
            g2d.fillRect(0, 0, getWidth(), getHeight());
            g2d.dispose();
        }
    }
}

// =========================================================================
// TESTIMONIAL CLASSES
// =========================================================================

class Testimonial {
    String authorName;
    String testimonialText;
    String profilePicturePath;
    String petImagePath;

    public Testimonial(String authorName, String testimonialText, String profilePicturePath, String petImagePath) {
        this.authorName = authorName;
        this.testimonialText = testimonialText;
        this.profilePicturePath = profilePicturePath;
        this.petImagePath = petImagePath;
    }

    public String getAuthorName() { return authorName; }
    public String getTestimonialText() { return testimonialText; }
    public String getProfilePicturePath() { return profilePicturePath; }
    public String getPetImagePath() { return petImagePath; }
}

class TestimonialCard extends ShadowPanel {
    private static final int PROFILE_IMAGE_SIZE = 60;
    private static final int PET_IMAGE_SIZE = 70;

    public TestimonialCard(Testimonial testimonial) {
        super(new BorderLayout(15, 15));
        setBackground(Color.WHITE);
        setBorderRadius(20);
        setShadowSize(15);
        setShadowColor(new Color(0, 0, 0, 40));
        setPreferredSize(new Dimension(320, 240));
        setMaximumSize(new Dimension(320, 240));

        JLabel profilePicLabel = new JLabel() {
            private Image profileImage;
            private ImageIcon defaultIcon;

            {
                ImageIcon originalIcon = createScaledIcon(testimonial.getProfilePicturePath(), PROFILE_IMAGE_SIZE, PROFILE_IMAGE_SIZE);
                if (originalIcon != null) {
                    profileImage = originalIcon.getImage();
                } else {
                    defaultIcon = createScaledIcon("/icons/default_profile.png", PROFILE_IMAGE_SIZE, PROFILE_IMAGE_SIZE);
                    if (defaultIcon == null) {
                        BufferedImage bufferedImage = new BufferedImage(PROFILE_IMAGE_SIZE, PROFILE_IMAGE_SIZE, BufferedImage.TYPE_INT_ARGB);
                        Graphics2D g2d = (Graphics2D) bufferedImage.getGraphics();
                        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                        g2d.setColor(new Color(180, 180, 180));
                        g2d.fillOval(0, 0, PROFILE_IMAGE_SIZE, PROFILE_IMAGE_SIZE);
                        g2d.setColor(Color.WHITE);
                        g2d.fillOval(PROFILE_IMAGE_SIZE / 4, PROFILE_IMAGE_SIZE / 8, PROFILE_IMAGE_SIZE / 2, PROFILE_IMAGE_SIZE / 2);
                        g2d.fillRect(PROFILE_IMAGE_SIZE / 4, PROFILE_IMAGE_SIZE / 2, PROFILE_IMAGE_SIZE / 2, PROFILE_IMAGE_SIZE / 2);
                        g2d.dispose();
                        defaultIcon = new ImageIcon(bufferedImage);
                    }
                    profileImage = defaultIcon.getImage();
                }
            }

            @Override
            protected void paintComponent(Graphics g) {
                if (profileImage != null) {
                    Graphics2D g2d = (Graphics2D) g.create();
                    g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    Ellipse2D.Double circle = new Ellipse2D.Double(0, 0, PROFILE_IMAGE_SIZE, PROFILE_IMAGE_SIZE);
                    g2d.setClip(circle);
                    g2d.drawImage(profileImage, 0, 0, PROFILE_IMAGE_SIZE, PROFILE_IMAGE_SIZE, this);
                    g2d.dispose();
                }
                super.paintComponent(g);
            }

            @Override
            public Dimension getPreferredSize() {
                return new Dimension(PROFILE_IMAGE_SIZE, PROFILE_IMAGE_SIZE);
            }
        };

        JLabel petPicLabel = new JLabel() {
            private Image petImage;
            private ImageIcon defaultPetIcon;

            {
                ImageIcon originalIcon = createScaledIcon(testimonial.getPetImagePath(), PET_IMAGE_SIZE, PET_IMAGE_SIZE);
                if (originalIcon != null) {
                    petImage = originalIcon.getImage();
                } else {
                    defaultPetIcon = createScaledIcon("/icons/default_pet.png", PET_IMAGE_SIZE, PET_IMAGE_SIZE);
                    if (defaultPetIcon == null) {
                        BufferedImage bufferedImage = new BufferedImage(PET_IMAGE_SIZE, PET_IMAGE_SIZE, BufferedImage.TYPE_INT_ARGB);
                        Graphics2D g2d = (Graphics2D) bufferedImage.getGraphics();
                        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                        g2d.setColor(new Color(200, 200, 200));
                        g2d.fillRoundRect(0, 0, PET_IMAGE_SIZE, PET_IMAGE_SIZE, 15, 15);
                        g2d.setColor(new Color(100, 100, 100));
                        int pawPadSize = PET_IMAGE_SIZE / 5;
                        int mainPadSize = PET_IMAGE_SIZE / 2;
                        g2d.fillOval(PET_IMAGE_SIZE / 2 - pawPadSize / 2, PET_IMAGE_SIZE / 4, pawPadSize, pawPadSize);
                        g2d.fillOval(PET_IMAGE_SIZE / 4, PET_IMAGE_SIZE / 3 + pawPadSize / 2, pawPadSize, pawPadSize);
                        g2d.fillOval(PET_IMAGE_SIZE * 3 / 4 - pawPadSize, PET_IMAGE_SIZE / 3 + pawPadSize / 2, pawPadSize, pawPadSize);
                        g2d.fillOval(PET_IMAGE_SIZE / 2 - mainPadSize / 2, PET_IMAGE_SIZE / 2, mainPadSize, mainPadSize / 2);
                        g2d.dispose();
                        defaultPetIcon = new ImageIcon(bufferedImage);
                    }
                    petImage = defaultPetIcon.getImage();
                }
            }

            @Override
            protected void paintComponent(Graphics g) {
                if (petImage != null) {
                    Graphics2D g2d = (Graphics2D) g.create();
                    g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    RoundRectangle2D roundedRect = new RoundRectangle2D.Double(0, 0, PET_IMAGE_SIZE, PET_IMAGE_SIZE, 15, 15);
                    g2d.setClip(roundedRect);
                    g2d.drawImage(petImage, 0, 0, PET_IMAGE_SIZE, PET_IMAGE_SIZE, this);
                    g2d.dispose();
                }
                super.paintComponent(g);
            }

            @Override
            public Dimension getPreferredSize() {
                return new Dimension(PET_IMAGE_SIZE, PET_IMAGE_SIZE);
            }
        };

        JPanel topPanel = new JPanel(new GridBagLayout());
        topPanel.setOpaque(false);
        topPanel.setBorder(new EmptyBorder(10, 10, 0, 10));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(0, 0, 0, 0);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets.right = 8;
        gbc.anchor = GridBagConstraints.WEST;
        topPanel.add(profilePicLabel, gbc);

        JLabel authorLabel = new JLabel(testimonial.getAuthorName());
        authorLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
        authorLabel.setForeground(new Color(0, 94, 70));
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        gbc.insets.right = 8;
        gbc.anchor = GridBagConstraints.WEST;
        topPanel.add(authorLabel, gbc);

        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.weightx = 0;
        gbc.insets.right = 0;
        gbc.anchor = GridBagConstraints.EAST;
        topPanel.add(petPicLabel, gbc);

        add(topPanel, BorderLayout.NORTH);

        JTextArea testimonialArea = new JTextArea(testimonial.getTestimonialText());
        testimonialArea.setFont(new Font("Times New Roman", Font.ITALIC, 14));
        testimonialArea.setForeground(new Color(51, 51, 51));
        testimonialArea.setLineWrap(true);
        testimonialArea.setWrapStyleWord(true);
        testimonialArea.setOpaque(false);
        testimonialArea.setEditable(false);
        testimonialArea.setFocusable(false);
        testimonialArea.setBorder(new EmptyBorder(0, 10, 10, 10));
        add(testimonialArea, BorderLayout.CENTER);
    }

    private ImageIcon createScaledIcon(String iconPath, int width, int height) {
        try {
            URL imgURL = getClass().getResource(iconPath);
            if (imgURL != null) {
                ImageIcon originalIcon = new ImageIcon(imgURL);
                Image scaledImage = originalIcon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
                return new ImageIcon(scaledImage);
            } else {
                return null;
            }
        } catch (Exception ex) {
            System.err.println("Error loading icon '" + iconPath + "': " + ex.getMessage());
            return null;
        }
    }
}

class TestimonialsSectionPanel extends JPanel {
    private final Color PRIMARY_BRAND_BLUE = new Color(0, 94, 70);
    private final Font SECTION_TITLE_FONT = new Font("Broadway", Font.BOLD, 40);
    private final Color NEUTRAL_GREY_DARK = new Color(51, 51, 51);

    private List<Testimonial> allTestimonials;
    private JPanel cardsPanel;
    private JButton leftArrowButton;
    private JButton rightArrowButton;

    private int currentPage = 0;
    private final int ITEMS_PER_PAGE = 3;

    public TestimonialsSectionPanel(List<Testimonial> testimonials) {
        this.allTestimonials = testimonials;

        setLayout(new BorderLayout());
        setBackground(new Color(240, 240, 240));
        setBorder(new EmptyBorder(50, 50, 50, 50));

        JLabel titleLabel = new JLabel("What Our Adopters Say");
        titleLabel.setFont(SECTION_TITLE_FONT);
        titleLabel.setForeground(PRIMARY_BRAND_BLUE);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setBorder(new EmptyBorder(0, 0, 40, 0));
        add(titleLabel, BorderLayout.NORTH);

        JPanel contentWrapper = new JPanel(new BorderLayout(30, 0));
        contentWrapper.setOpaque(false);

        cardsPanel = new JPanel(new WrapLayout(FlowLayout.CENTER, 30, 30));
        cardsPanel.setOpaque(false);

        leftArrowButton = createArrowButton("/icons/left_arrow.png", "<");
        rightArrowButton = createArrowButton("/icons/Right_arrow.png", ">");

        leftArrowButton.addActionListener(e -> showPreviousPage());
        rightArrowButton.addActionListener(e -> showNextPage());

        contentWrapper.add(leftArrowButton, BorderLayout.WEST);
        contentWrapper.add(cardsPanel, BorderLayout.CENTER);
        contentWrapper.add(rightArrowButton, BorderLayout.EAST);

        add(contentWrapper, BorderLayout.CENTER);

        updateTestimonialCards();
    }

    private JButton createArrowButton(String iconPath, String tooltip) {
        JButton button = new JButton();
        try {
            URL imgURL = getClass().getResource(iconPath);
            if (imgURL != null) {
                ImageIcon originalIcon = new ImageIcon(imgURL);
                Image scaledImage = originalIcon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
                button.setIcon(new ImageIcon(scaledImage));
            } else {
                button.setText(tooltip.substring(0,1));
                button.setFont(new Font("Times New Roman", Font.BOLD, 30));
                button.setForeground(NEUTRAL_GREY_DARK.darker());
                System.err.println("Error: Arrow icon not found: " + iconPath + ". Using text fallback.");
            }
        } catch (Exception ex) {
            button.setText(tooltip.substring(0,1));
            button.setFont(new Font("Times New Roman", Font.BOLD, 30));
            button.setForeground(NEUTRAL_GREY_DARK.darker());
            System.err.println("Error loading arrow icon '" + iconPath + "': " + ex.getMessage() + ". Using text fallback.");
        }
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setOpaque(false);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(60, 240));
        return button;
    }

    private void updateTestimonialCards() {
        cardsPanel.removeAll();

        int startIndex = currentPage * ITEMS_PER_PAGE;
        int endIndex = Math.min(startIndex + ITEMS_PER_PAGE, allTestimonials.size());

        for (int i = startIndex; i < endIndex; i++) {
            cardsPanel.add(new TestimonialCard(allTestimonials.get(i)));
        }

        cardsPanel.revalidate();
        cardsPanel.repaint();
        updateNavigationButtons();
    }

    private void showNextPage() {
        int maxStartIndex = (int) Math.floor((double)(allTestimonials.size() - 1) / ITEMS_PER_PAGE) * ITEMS_PER_PAGE;
        if (currentPage * ITEMS_PER_PAGE < maxStartIndex) {
            currentPage++;
            updateTestimonialCards();
        }
    }

    private void showPreviousPage() {
        if (currentPage > 0) {
            currentPage--;
            updateTestimonialCards();
        }
    }

    private void updateNavigationButtons() {
        leftArrowButton.setEnabled(currentPage > 0);
        int maxStartIndex = (int) Math.floor((double)(allTestimonials.size() - 1) / ITEMS_PER_PAGE) * ITEMS_PER_PAGE;
        rightArrowButton.setEnabled(currentPage * ITEMS_PER_PAGE < maxStartIndex);
    }
}

// =========================================================================
// ADOPTION RECORD CLASSES
// =========================================================================

class AdoptionRecord {
    private static int nextId = 1;
    private String recordId;
    private String petId;
    private String petName;
    private String species;
    private String adopterName;
    private String phone;
    private String adoptionDate;
    private String status;
    private String notes;

    public AdoptionRecord(String petName, String species, String adopterName, String phone, String adoptionDate, String status, String notes, String petId) {
        this.recordId = String.format("A%03d", nextId++);
        this.petName = petName;
        this.species = species;
        this.adopterName = adopterName;
        this.phone = phone;
        this.adoptionDate = adoptionDate;
        this.status = status;
        this.notes = notes;
        this.petId = petId != null ? petId : "N/A";
    }

    public AdoptionRecord() {}

    public static void setNextId(int id) {
        nextId = id;
    }

    public String getRecordId() { return recordId; }
    public String getPetId() { return petId != null ? petId : "N/A"; }
    public String getPetName() { return petName; }
    public String getSpecies() { return species; }
    public String getAdopterName() { return adopterName; }
    public String getPhone() { return phone; }
    public String getAdoptionDate() { return adoptionDate; }
    public String getStatus() { return status; }
    public String getNotes() { return notes; }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Object[] toArray() {
        return new Object[]{recordId, getPetId(), petName, species, adopterName, phone, adoptionDate, status, notes};
    }
}

class AdoptionRecordManager {
    private static List<AdoptionRecord> records;

    static {
        records = DataPersistenceManager.loadAdoptionRecords();
    }

    public static List<AdoptionRecord> loadRecords() {
        return new ArrayList<>(records);
    }

    public static void saveRecords(List<AdoptionRecord> newRecords) {
        records = new ArrayList<>(newRecords);
        DataPersistenceManager.saveAdoptionRecords(records);
    }

    public static void addRecord(AdoptionRecord record) {
        records.add(record);
        DataPersistenceManager.saveAdoptionRecords(records);
    }

    public static void updateRecordStatus(String recordId, String newStatus, String newNotes) {
        boolean updated = false;
        for (AdoptionRecord record : records) {
            if (record.getRecordId().equals(recordId)) {
                record.setStatus(newStatus);
                record.setNotes(newNotes);
                updated = true;
                break;
            }
        }
        if (updated) {
            DataPersistenceManager.saveAdoptionRecords(records);
        }
    }

    public static boolean removeRecord(String recordId) {
        for (int i = 0; i < records.size(); i++) {
            if (records.get(i).getRecordId().equals(recordId)) {
                records.remove(i);
                DataPersistenceManager.saveAdoptionRecords(records);
                return true;
            }
        }
        return false;
    }
}

// =========================================================================
// ADOPTION RECORDS PANEL - FIXED SEARCH FUNCTIONALITY
// =========================================================================

class AdoptionRecordsPanel extends JPanel {
    private final Color PRIMARY_BRAND_BLUE = new Color(0, 94, 70);
    private final Font SECTION_TITLE_FONT = new Font("Broadway", Font.BOLD, 40);
    private final Font LABEL_FONT = new Font("Arial", Font.PLAIN, 14);
    private final Color NEUTRAL_GREY_DARK = new Color(51, 51, 51);

    private List<AdoptionRecord> allRecords;
    private JTable recordsTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    private JComboBox<String> statusFilterComboBox;

    public AdoptionRecordsPanel() {
        setLayout(new BorderLayout());
        setBackground(new Color(240, 240, 240));
        setBorder(new EmptyBorder(30, 30, 30, 30));

        JLabel titleLabel = new JLabel("Adoption Records Management");
        titleLabel.setFont(SECTION_TITLE_FONT);
        titleLabel.setForeground(PRIMARY_BRAND_BLUE);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setBorder(new EmptyBorder(0, 0, 20, 0));
        add(titleLabel, BorderLayout.NORTH);

        setupSearchAndFilters();

        String[] columnNames = {"Record ID", "Pet ID", "Pet Name", "Species", "Adopter Name", "Phone", "Adoption Date", "Status", "Notes"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        recordsTable = new JTable(tableModel);
        recordsTable.setRowHeight(25);
        recordsTable.setFont(new Font("Arial", Font.PLAIN, 14));
        recordsTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        recordsTable.getTableHeader().setBackground(PRIMARY_BRAND_BLUE.brighter());
        recordsTable.getTableHeader().setForeground(Color.WHITE);
        recordsTable.setFillsViewportHeight(true);
        recordsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(recordsTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(PRIMARY_BRAND_BLUE, 2));
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setOpaque(false);
        buttonPanel.setBorder(new EmptyBorder(20, 0, 0, 0));

        JButton editButton = createActionButton("Edit Record", new Color(0, 94, 70));
        editButton.addActionListener(e -> editRecord());
        buttonPanel.add(editButton);

        JButton deleteButton = createActionButton("Delete Record", new Color(220, 53, 69));
        deleteButton.addActionListener(e -> deleteRecord());
        buttonPanel.add(deleteButton);

        add(buttonPanel, BorderLayout.SOUTH);

        loadAndDisplayRecords();
    }

    private void setupSearchAndFilters() {
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        controlPanel.setOpaque(false);
        controlPanel.setBorder(new EmptyBorder(10, 0, 20, 0));

        controlPanel.add(new JLabel("Search:"));
        searchField = new JTextField(20);
        searchField.setFont(LABEL_FONT);

        searchField.getDocument().addDocumentListener(new DocumentListener() {
            private Timer timer;

            @Override
            public void insertUpdate(DocumentEvent e) {
                scheduleFilterUpdate();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                scheduleFilterUpdate();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                scheduleFilterUpdate();
            }

            private void scheduleFilterUpdate() {
                if (timer != null) {
                    timer.stop();
                }
                timer = new Timer(300, e -> filterAndRefreshTable());
                timer.setRepeats(false);
                timer.start();
            }
        });

        controlPanel.add(searchField);

        controlPanel.add(new JLabel("Status:"));
        statusFilterComboBox = new JComboBox<>(new String[]{"All", "Approved", "Pending", "Cancelled"});

        statusFilterComboBox.addActionListener(e -> {
            SwingUtilities.invokeLater(() -> filterAndRefreshTable());
        });

        controlPanel.add(statusFilterComboBox);

        add(controlPanel, BorderLayout.NORTH);
    }

    private JButton createActionButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setForeground(Color.WHITE);
        button.setBackground(bgColor);
        button.setOpaque(true);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        return button;
    }

    public void loadAndDisplayRecords() {
        allRecords = AdoptionRecordManager.loadRecords();
        filterAndRefreshTable();
    }

    private void filterAndRefreshTable() {
        tableModel.setRowCount(0);

        String searchTerm = searchField.getText().toLowerCase().trim();
        String selectedStatus = (String) statusFilterComboBox.getSelectedItem();

        for (AdoptionRecord record : allRecords) {
            boolean matchSearch = searchTerm.isEmpty() ||
                    (record.getPetName() != null && record.getPetName().toLowerCase().contains(searchTerm)) ||
                    (record.getAdopterName() != null && record.getAdopterName().toLowerCase().contains(searchTerm)) ||
                    (record.getRecordId() != null && record.getRecordId().toLowerCase().contains(searchTerm)) ||
                    (record.getPetId() != null && record.getPetId().toLowerCase().contains(searchTerm)) ||
                    (record.getSpecies() != null && record.getSpecies().toLowerCase().contains(searchTerm)) ||
                    (record.getNotes() != null && record.getNotes().toLowerCase().contains(searchTerm)) ||
                    (record.getPhone() != null && record.getPhone().contains(searchTerm)) ||
                    (record.getAdoptionDate() != null && record.getAdoptionDate().toLowerCase().contains(searchTerm));

            boolean matchStatus = selectedStatus.equals("All") ||
                    (record.getStatus() != null && record.getStatus().equalsIgnoreCase(selectedStatus));

            if (matchSearch && matchStatus) {
                tableModel.addRow(record.toArray());
            }
        }
    }

    private void editRecord() {
        int selectedRow = recordsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a record to edit.", "No Record Selected", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String recordIdToEdit = (String) recordsTable.getValueAt(selectedRow, 0);
        String petIdAssociated = (String) recordsTable.getValueAt(selectedRow, 1);
        String petNameToEdit = (String) recordsTable.getValueAt(selectedRow, 2);

        AdoptionRecord recordToEdit = null;
        for (AdoptionRecord record : allRecords) {
            if (record.getRecordId().equals(recordIdToEdit)) {
                recordToEdit = record;
                break;
            }
        }

        if (recordToEdit != null) {
            String[] statusOptions = {"Approved", "Pending", "Cancelled"};

            String newStatus = (String) JOptionPane.showInputDialog(
                    this,
                    "Select new status for " + petNameToEdit + " (Record ID: " + recordIdToEdit + "):",
                    "Edit Status",
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    statusOptions,
                    recordToEdit.getStatus()
            );

            if (newStatus != null && !newStatus.isEmpty()) {
                String newNotes = JOptionPane.showInputDialog(
                        this,
                        "Enter new notes for " + petNameToEdit + " (Record ID: " + recordIdToEdit + "):",
                        recordToEdit.getNotes()
                );

                if (newNotes != null) {
                    String oldStatus = recordToEdit.getStatus();

                    AdoptionRecordManager.updateRecordStatus(recordIdToEdit, newStatus, newNotes);

                    if (newStatus.equals("Approved")) {
                        PetManager.updatePetStatus(petIdAssociated, "Adopted");
                    } else if (newStatus.equals("Cancelled") && oldStatus.equals("Pending")) {
                        PetManager.updatePetStatus(petIdAssociated, "Available");
                    } else if (newStatus.equals("Pending") && oldStatus.equals("Available")) {
                        PetManager.updatePetStatus(petIdAssociated, "Pending");
                    } else if (newStatus.equals("Pending") && oldStatus.equals("Cancelled")) {
                        PetManager.updatePetStatus(petIdAssociated, "Pending");
                    }

                    allRecords = AdoptionRecordManager.loadRecords();
                    filterAndRefreshTable();
                    JOptionPane.showMessageDialog(this, "Record " + recordIdToEdit + " updated successfully.", "Update Successful", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Error: Selected record not found in data.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteRecord() {
        int selectedRow = recordsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a record to delete.", "No Record Selected", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String recordIdToDelete = (String) recordsTable.getValueAt(selectedRow, 0);
        String petIdAssociated = (String) recordsTable.getValueAt(selectedRow, 1);
        String petNameAssociated = (String) recordsTable.getValueAt(selectedRow, 2);
        String recordStatus = (String) recordsTable.getValueAt(selectedRow, 7);

        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete record " + recordIdToDelete + " for pet " + petNameAssociated + "?\n" +
                        "This action cannot be undone.", "Confirm Deletion", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            if (AdoptionRecordManager.removeRecord(recordIdToDelete)) {
                if (recordStatus.equals("Pending")) {
                    PetManager.updatePetStatus(petIdAssociated, "Available");
                }

                allRecords = AdoptionRecordManager.loadRecords();
                filterAndRefreshTable();
                JOptionPane.showMessageDialog(this, "Record " + recordIdToDelete + " deleted successfully.", "Deletion Successful", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Error: Could not find record " + recordIdToDelete + " to delete.", "Deletion Failed", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
// =========================================================================
// ADD PET PANEL (UPDATED WITH CALENDAR)
// =========================================================================

class AddPetPanel extends JPanel {
    private final Color PRIMARY_BRAND_BLUE = new Color(0, 94, 70);
    private final Color ACCENT_ORANGE = new Color(154, 103, 53);
    private final Color TEXT_WHITE = Color.WHITE;
    private final Color NEUTRAL_GREY_DARK = new Color(0, 94, 70);
    private final Color PRIMARY = PRIMARY_BRAND_BLUE;
    private final Color BG = new Color(248, 249, 251);
    private final Color CARD_BG = Color.WHITE;
    private final Color SUBHEADER = new Color(70, 70, 70);
    private final Font HEADER_FONT = new Font("SansSerif", Font.BOLD, 30);
    private final Font LABEL_FONT = new Font("SansSerif", Font.BOLD, 14);
    private final Font INPUT_FONT = new Font("SansSerif", Font.PLAIN, 14);
    private final Font BUTTON_FONT = new Font("SansSerif", Font.BOLD, 16);

    private final JTextField idField = new JTextField(12);
    private final JRadioButton dogRadio = new JRadioButton("Dog");
    private final JRadioButton catRadio = new JRadioButton("Cat");
    private final JRadioButton birdRadio = new JRadioButton("Bird");
    private final JRadioButton rabbitRadio = new JRadioButton("Rabbit");
    private final JRadioButton fishRadio = new JRadioButton("Fish");
    private final ButtonGroup typeGroup = new ButtonGroup();
    private final JTextField dobField = new JTextField(10); // Changed from JSpinner to JTextField
    private final JLabel ageLabel = new JLabel("Calculated Age: 0 years");
    private final JTextField nameField = new JTextField(16);
    private final JComboBox<String> breedCombo = new JComboBox<>();
    private final JComboBox<String> sizeCombo = new JComboBox<>(new String[]{"Small", "Medium", "Large"});
    private final JComboBox<String> healthCombo = new JComboBox<>(new String[]{"Healthy", "Needs Care", "Under Observation"});
    private final JCheckBox vaccCheck = new JCheckBox("Vaccinated");
    private final JLabel imageLabel = new JLabel("<html><center>Image Preview</center></html>");
    private String imagePath = "";
    private final JLabel nameErrorLabel = new JLabel(" Name cannot contain numbers");
    private JButton uploadButton = new JButton("Upload Image");
    private JButton saveButton = new JButton("Add Pet");
    private JButton resetButton = new JButton("Reset");
    private JButton calendarButton = new JButton("📅"); // Calendar button
    private JTextArea activityLogArea;

    private static final Map<String, String[]> BREEDS = new HashMap<>();
    static {
        BREEDS.put("Dog", new String[]{"German Shepherd", "Husky", "Labrador", "Beagle", "Bulldog"});
        BREEDS.put("Cat", new String[]{"Persian", "Siamese", "Bengal", "Maine Coon"});
        BREEDS.put("Bird", new String[]{"Canary", "Parrot", "Finch"});
        BREEDS.put("Rabbit", new String[]{"Netherland Dwarf", "Lionhead", "Mini Lop"});
        BREEDS.put("Fish", new String[]{"Goldfish", "Betta", "Discus", "Betta Splendens"});
    }

    public AddPetPanel() {
        setLayout(new BorderLayout());
        setBackground(BG);
        setBorder(new EmptyBorder(20, 40, 20, 40));

        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.BOTH;

        JPanel leftPanel = createLeftFormPanel();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.weightx = 0.7;
        gbc.weighty = 1.0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        mainPanel.add(leftPanel, gbc);

        JPanel rightPanel = createRightPanel();
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.weightx = 0.3;
        gbc.anchor = GridBagConstraints.NORTHEAST;
        mainPanel.add(rightPanel, gbc);

        add(mainPanel, BorderLayout.CENTER);
        initializeComponents();
        updateAgeLabel();
    }

    private JPanel createLeftFormPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(CARD_BG);
        panel.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(200, 200, 200), 1),
                new EmptyBorder(20, 20, 20, 20)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        int row = 0;

        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        panel.add(createLabel("Pet Type:"), gbc);

        gbc.gridy = ++row;
        JPanel typePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 5));
        typePanel.setOpaque(false);
        typePanel.add(dogRadio); typePanel.add(catRadio);
        typePanel.add(birdRadio); typePanel.add(rabbitRadio);
        typePanel.add(fishRadio);
        panel.add(typePanel, gbc);

        gbc.gridy = ++row;
        panel.add(createLabel("Auto-Generated Pet ID:"), gbc);

        gbc.gridy = ++row;
        idField.setEditable(false);
        idField.setBackground(new Color(240, 240, 240));
        panel.add(createStyledField(idField), gbc);

        gbc.gridy = ++row;
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.weightx = 0.6;
        JPanel dobPanel = new JPanel(new BorderLayout());
        dobPanel.setOpaque(false);
        dobPanel.add(createLabel("Date of Birth:"), BorderLayout.NORTH);

        // Create panel for date field and calendar button
        JPanel dobInputPanel = new JPanel(new BorderLayout());
        dobInputPanel.setOpaque(false);
        dobField.setFont(INPUT_FONT);
        dobField.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(Color.LIGHT_GRAY),
                new EmptyBorder(8, 10, 8, 10)
        ));
        dobInputPanel.add(dobField, BorderLayout.CENTER);

        // Style the calendar button
        calendarButton.setFont(new Font("SansSerif", Font.PLAIN, 16));
        calendarButton.setBackground(new Color(240, 240, 240));
        calendarButton.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(Color.LIGHT_GRAY),
                new EmptyBorder(5, 10, 5, 10)
        ));
        calendarButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        calendarButton.setToolTipText("Select Date from Calendar");
        calendarButton.addActionListener(e -> showCalendarDialog());
        dobInputPanel.add(calendarButton, BorderLayout.EAST);

        dobPanel.add(dobInputPanel, BorderLayout.CENTER);
        panel.add(dobPanel, gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.4;
        JPanel agePanel = new JPanel(new BorderLayout());
        agePanel.setOpaque(false);
        agePanel.add(createLabel("Age:"), BorderLayout.NORTH);
        ageLabel.setFont(INPUT_FONT);
        ageLabel.setForeground(NEUTRAL_GREY_DARK);
        JPanel ageFieldPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        ageFieldPanel.setBackground(CARD_BG);
        ageFieldPanel.add(ageLabel);
        agePanel.add(ageFieldPanel, BorderLayout.CENTER);
        panel.add(agePanel, gbc);

        gbc.gridx = 0; gbc.gridy = ++row; gbc.gridwidth = 2; gbc.weightx = 1.0;
        JSeparator separator = new JSeparator(SwingConstants.HORIZONTAL);
        separator.setForeground(new Color(200, 200, 200));
        panel.add(separator, gbc);

        gbc.gridy = ++row; gbc.gridwidth = 2;
        panel.add(createLabel("Name:"), gbc);

        gbc.gridy = ++row;
        panel.add(createStyledField(nameField), gbc);

        gbc.gridy = ++row; gbc.insets = new Insets(2, 8, 8, 8);
        nameErrorLabel.setFont(new Font("SansSerif", Font.PLAIN, 11));
        nameErrorLabel.setForeground(new Color(220, 53, 69));
        nameErrorLabel.setVisible(false);
        panel.add(nameErrorLabel, gbc);
        gbc.insets = new Insets(8, 8, 8, 8);

        gbc.gridy = ++row; gbc.gridwidth = 1;
        gbc.gridx = 0; gbc.weightx = 0.5;
        JPanel breedPanel = new JPanel(new BorderLayout());
        breedPanel.setOpaque(false);
        breedPanel.add(createLabel("Breed:"), BorderLayout.NORTH);
        breedPanel.add(createStyledComboBox(breedCombo), BorderLayout.CENTER);
        panel.add(breedPanel, gbc);

        gbc.gridx = 1; gbc.weightx = 0.5;
        JPanel sizePanel = new JPanel(new BorderLayout());
        sizePanel.setOpaque(false);
        sizePanel.add(createLabel("Size:"), BorderLayout.NORTH);
        sizePanel.add(createStyledComboBox(sizeCombo), BorderLayout.CENTER);
        panel.add(sizePanel, gbc);

        gbc.gridy = ++row;
        gbc.gridx = 0;
        JPanel healthPanel = new JPanel(new BorderLayout());
        healthPanel.setOpaque(false);
        healthPanel.add(createLabel("Health Status:"), BorderLayout.NORTH);
        healthPanel.add(createStyledComboBox(healthCombo), BorderLayout.CENTER);
        panel.add(healthPanel, gbc);

        gbc.gridx = 1;
        JPanel vaccPanel = new JPanel(new BorderLayout());
        vaccPanel.setOpaque(false);
        vaccPanel.add(createLabel("Vaccination Status:"), BorderLayout.NORTH);
        JPanel checkPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        checkPanel.setOpaque(false);
        checkPanel.add(vaccCheck);
        vaccPanel.add(checkPanel, BorderLayout.CENTER);
        panel.add(vaccPanel, gbc);

        gbc.gridx = 1;
        gbc.gridy = row;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.EAST;

        JPanel buttonPlacementPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttonPlacementPanel.setOpaque(false);
        buttonPlacementPanel.add(resetButton);
        buttonPlacementPanel.add(saveButton);
        panel.add(buttonPlacementPanel, gbc);

        return panel;
    }

    private JPanel createRightPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridwidth = GridBagConstraints.REMAINDER;

        gbc.gridy = 0;
        gbc.weightx = 1.0;
        imageLabel.setPreferredSize(new Dimension(300, 200));
        imageLabel.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(200, 200, 200), 1),
                new EmptyBorder(10, 10, 10, 10)
        ));
        imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        imageLabel.setVerticalAlignment(SwingConstants.CENTER);
        imageLabel.setOpaque(true);
        imageLabel.setBackground(new Color(250, 250, 250));
        panel.add(imageLabel, gbc);

        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(createStyledButton(uploadButton, ACCENT_ORANGE), gbc);

        gbc.gridy = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1.0;
        panel.add(createActivityLogPanel(), gbc);

        return panel;
    }

    private JPanel createActivityLogPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                "Activity Log",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                LABEL_FONT,
                PRIMARY
        ));
        panel.setBackground(CARD_BG);

        activityLogArea = new JTextArea(10, 25);
        activityLogArea.setEditable(false);
        activityLogArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        activityLogArea.setLineWrap(true);
        activityLogArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(activityLogArea);
        panel.add(scrollPane, BorderLayout.CENTER);
        return panel;
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(LABEL_FONT);
        label.setForeground(SUBHEADER);
        return label;
    }

    private JComponent createStyledField(JComponent field) {
        field.setFont(INPUT_FONT);
        field.setBackground(CARD_BG);
        if (field instanceof JTextField) {
            field.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(Color.LIGHT_GRAY),
                    new EmptyBorder(8, 10, 8, 10)
            ));
        }
        return field;
    }

    private JComboBox<String> createStyledComboBox(JComboBox<String> combo) {
        combo.setFont(INPUT_FONT);
        combo.setBackground(CARD_BG);
        combo.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(Color.LIGHT_GRAY),
                new EmptyBorder(8, 10, 8, 10)
        ));
        return combo;
    }

    private JButton createStyledButton(JButton button, Color bgColor) {
        button.setFont(BUTTON_FONT);
        button.setForeground(TEXT_WHITE);
        button.setBackground(bgColor);
        button.setOpaque(true);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(bgColor.darker());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(bgColor);
            }
        });

        return button;
    }

    private void initializeComponents() {
        dogRadio.setSelected(true);
        typeGroup.add(dogRadio);
        typeGroup.add(catRadio);
        typeGroup.add(birdRadio);
        typeGroup.add(rabbitRadio);
        typeGroup.add(fishRadio);

        Font radioFont = new Font("SansSerif", Font.PLAIN, 14);
        dogRadio.setFont(radioFont);
        catRadio.setFont(radioFont);
        birdRadio.setFont(radioFont);
        rabbitRadio.setFont(radioFont);
        fishRadio.setFont(radioFont);

        vaccCheck.setFont(INPUT_FONT);

        // Set current date as default in dobField
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        dobField.setText(sdf.format(new Date()));

        updateBreedOptions();
        updateAutoId();

        addEventListeners();

        this.saveButton = createStyledButton(saveButton, PRIMARY_BRAND_BLUE);
        this.resetButton = createStyledButton(resetButton, new Color(154, 103, 53));
        this.uploadButton = createStyledButton(uploadButton, ACCENT_ORANGE);

        logActivity("Application started.");
    }

    private void addEventListeners() {
        dogRadio.addActionListener(e -> onTypeChanged());
        catRadio.addActionListener(e -> onTypeChanged());
        birdRadio.addActionListener(e -> onTypeChanged());
        rabbitRadio.addActionListener(e -> onTypeChanged());
        fishRadio.addActionListener(e -> onTypeChanged());

        // Add document listener to dobField for real-time age calculation
        dobField.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { updateAgeLabel(); }
            @Override public void removeUpdate(DocumentEvent e) { updateAgeLabel(); }
            @Override public void changedUpdate(DocumentEvent e) { updateAgeLabel(); }
        });

        uploadButton.addActionListener(this::handleImageUpload);

        saveButton.addActionListener(e -> handleSave());
        resetButton.addActionListener(e -> clearForm());

        // Calendar button listener is already added in createLeftFormPanel()

        nameField.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { validateName(); }
            @Override public void removeUpdate(DocumentEvent e) { validateName(); }
            @Override public void changedUpdate(DocumentEvent e) { validateName(); }
        });
    }

    private void showCalendarDialog() {
        // Create a dialog for calendar
        JDialog calendarDialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Select Date of Birth", true);
        calendarDialog.setLayout(new BorderLayout());
        calendarDialog.setSize(300, 300);
        calendarDialog.setLocationRelativeTo(this);

        // Create calendar panel
        JPanel calendarPanel = new JPanel(new BorderLayout());

        // Create month navigation
        JPanel navigationPanel = new JPanel(new FlowLayout());
        JButton prevButton = new JButton("←");
        JButton nextButton = new JButton("→");
        JLabel monthLabel = new JLabel("", SwingConstants.CENTER);
        navigationPanel.add(prevButton);
        navigationPanel.add(monthLabel);
        navigationPanel.add(nextButton);

        // Create calendar grid
        JPanel daysPanel = new JPanel(new GridLayout(0, 7));

        // Initialize calendar with current date
        Calendar calendar = Calendar.getInstance();
        updateCalendarDisplay(calendar, monthLabel, daysPanel, calendarDialog);

        // Add navigation listeners
        prevButton.addActionListener(e -> {
            calendar.add(Calendar.MONTH, -1);
            updateCalendarDisplay(calendar, monthLabel, daysPanel, calendarDialog);
        });

        nextButton.addActionListener(e -> {
            calendar.add(Calendar.MONTH, 1);
            updateCalendarDisplay(calendar, monthLabel, daysPanel, calendarDialog);
        });

        calendarPanel.add(navigationPanel, BorderLayout.NORTH);
        calendarPanel.add(daysPanel, BorderLayout.CENTER);

        calendarDialog.add(calendarPanel, BorderLayout.CENTER);
        calendarDialog.setVisible(true);
    }

    private void updateCalendarDisplay(Calendar calendar, JLabel monthLabel, JPanel daysPanel, JDialog dialog) {
        // Clear previous days
        daysPanel.removeAll();

        // Set month label
        SimpleDateFormat monthFormat = new SimpleDateFormat("MMMM yyyy");
        monthLabel.setText(monthFormat.format(calendar.getTime()));

        // Get the first day of month and number of days
        Calendar firstDay = (Calendar) calendar.clone();
        firstDay.set(Calendar.DAY_OF_MONTH, 1);

        int firstDayOfWeek = firstDay.get(Calendar.DAY_OF_WEEK);
        int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);

        // Add day headers
        String[] dayNames = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
        for (String dayName : dayNames) {
            JLabel headerLabel = new JLabel(dayName, SwingConstants.CENTER);
            headerLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
            headerLabel.setForeground(PRIMARY_BRAND_BLUE);
            headerLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
            daysPanel.add(headerLabel);
        }

        // Add empty cells for days before the first day of month
        // Note: Calendar.SUNDAY = 1, Calendar.SATURDAY = 7
        for (int i = Calendar.SUNDAY; i < firstDayOfWeek; i++) {
            JLabel emptyLabel = new JLabel("");
            emptyLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
            daysPanel.add(emptyLabel);
        }

        // Add day buttons
        Calendar today = Calendar.getInstance();

        for (int day = 1; day <= daysInMonth; day++) {
            JButton dayButton = new JButton(String.valueOf(day));
            dayButton.setFont(new Font("SansSerif", Font.PLAIN, 12));
            dayButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
            dayButton.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
            dayButton.setMargin(new Insets(5, 5, 5, 5));

            // Check if this is today
            boolean isToday = (calendar.get(Calendar.YEAR) == today.get(Calendar.YEAR) &&
                    calendar.get(Calendar.MONTH) == today.get(Calendar.MONTH) &&
                    day == today.get(Calendar.DAY_OF_MONTH));

            // Check if this is the selected date
            String currentDobText = dobField.getText().trim();
            boolean isSelected = false;
            if (!currentDobText.isEmpty()) {
                try {
                    SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
                    Date currentDob = sdf.parse(currentDobText);
                    Calendar currentDobCal = Calendar.getInstance();
                    currentDobCal.setTime(currentDob);

                    isSelected = (calendar.get(Calendar.YEAR) == currentDobCal.get(Calendar.YEAR) &&
                            calendar.get(Calendar.MONTH) == currentDobCal.get(Calendar.MONTH) &&
                            day == currentDobCal.get(Calendar.DAY_OF_MONTH));
                } catch (Exception e) {
                    // Ignore parsing errors
                }
            }

            if (isToday) {
                dayButton.setBackground(PRIMARY_BRAND_BLUE);
                dayButton.setForeground(Color.WHITE);
                dayButton.setOpaque(true);
                dayButton.setBorderPainted(false);
            } else if (isSelected) {
                dayButton.setBackground(ACCENT_ORANGE);
                dayButton.setForeground(Color.WHITE);
                dayButton.setOpaque(true);
                dayButton.setBorderPainted(false);
            } else {
                dayButton.setBackground(Color.WHITE);
                dayButton.setForeground(Color.BLACK);
                dayButton.setOpaque(true);
                dayButton.setBorderPainted(true);
                dayButton.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
            }

            final int selectedDay = day;
            dayButton.addActionListener(e -> {
                // Set the selected date in dobField
                Calendar selectedDate = (Calendar) calendar.clone();
                selectedDate.set(Calendar.DAY_OF_MONTH, selectedDay);

                SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
                dobField.setText(dateFormat.format(selectedDate.getTime()));

                // Close dialog
                dialog.dispose();

                logActivity("Date of birth selected: " + dateFormat.format(selectedDate.getTime()));
            });

            daysPanel.add(dayButton);
        }

        // Fill remaining cells to complete the grid (6 rows × 7 columns = 42 cells)
        int totalCells = 42; // 6 rows × 7 columns
        int cellsUsed = (firstDayOfWeek - 1) + daysInMonth;
        int cellsRemaining = totalCells - cellsUsed;

        for (int i = 0; i < cellsRemaining; i++) {
            JLabel emptyLabel = new JLabel("");
            emptyLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
            daysPanel.add(emptyLabel);
        }

        // Refresh the panel
        daysPanel.revalidate();
        daysPanel.repaint();
    }

    private void onTypeChanged() {
        sizeCombo.setVisible(dogRadio.isSelected());
        updateBreedOptions();
        updateAutoId();
        logActivity("Pet type changed to " + getSelectedType());
    }

    private void updateBreedOptions() {
        breedCombo.removeAllItems();
        String type = getSelectedType();
        String[] breeds = BREEDS.get(type);
        if (breeds != null) {
            for (String b : breeds) breedCombo.addItem(b);
        }
        if (breedCombo.getItemCount() > 0) {
            breedCombo.setSelectedIndex(0);
        }
    }

    private void updateAutoId() {
        String type = getSelectedType();
        idField.setText(PetManager.generateAutoId(type));
    }

    private void updateAgeLabel() {
        try {
            String dobText = dobField.getText().trim();
            if (!dobText.isEmpty()) {
                SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
                Date dobDate = sdf.parse(dobText);

                LocalDate birth = dobDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                LocalDate now = LocalDate.now();

                Period period = Period.between(birth, now);
                long totalMonths = ChronoUnit.MONTHS.between(birth, now);
                long totalDays = ChronoUnit.DAYS.between(birth, now);

                String ageText;
                if (period.getYears() > 0) {
                    ageText = String.format("Calculated Age: %d years, %d months", period.getYears(), period.getMonths());
                } else if (totalMonths > 0) {
                    ageText = String.format("Calculated Age: %d months, %d days", totalMonths % 12, period.getDays());
                } else if (totalDays >= 0) {
                    ageText = String.format("Calculated Age: %d days", totalDays);
                } else {
                    ageText = "Calculated Age: N/A (Future Date)";
                }
                ageLabel.setText(ageText);
            } else {
                ageLabel.setText("Calculated Age: N/A");
            }
        } catch (Exception e) {
            ageLabel.setText("Calculated Age: Error");
            System.err.println("Error calculating age: " + e.getMessage());
        }
    }

    private String getSelectedType() {
        if (dogRadio.isSelected()) return "Dog";
        if (catRadio.isSelected()) return "Cat";
        if (birdRadio.isSelected()) return "Bird";
        if (rabbitRadio.isSelected()) return "Rabbit";
        return "Fish";
    }

    private boolean validateName() {
        String name = nameField.getText().trim();
        boolean containsNumbers = name.matches(".*\\d.*");
        if (name.isEmpty()) {
            nameErrorLabel.setText(" Pet name cannot be empty");
            nameErrorLabel.setVisible(true);
            return false;
        } else if (containsNumbers) {
            nameErrorLabel.setText(" Name cannot contain numbers");
            nameErrorLabel.setVisible(true);
            return false;
        }
        nameErrorLabel.setVisible(false);
        return true;
    }

    private void handleImageUpload(ActionEvent e) {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileFilter(new FileNameExtensionFilter("Image Files", "jpg", "png", "jpeg"));
        int res = chooser.showOpenDialog(this);
        if (res == JFileChooser.APPROVE_OPTION) {
            try {
                File selectedFile = chooser.getSelectedFile();
                imagePath = selectedFile.getAbsolutePath();

                BufferedImage img = ImageIO.read(selectedFile);
                if (img == null) throw new IOException("Could not read image file.");

                Image scaled = img.getScaledInstance(280, 180, Image.SCALE_SMOOTH);
                imageLabel.setIcon(new ImageIcon(scaled));
                imageLabel.setText("");
                logActivity("Image uploaded: " + selectedFile.getName());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error uploading image: " + ex.getMessage(),
                        "Image Upload Error", JOptionPane.ERROR_MESSAGE);
                imagePath = "";
                imageLabel.setIcon(null);
                imageLabel.setText("<html><center>Upload Failed</center></html>");
                logActivity("Image upload failed: " + ex.getMessage());
            }
        }
    }

    private void handleSave() {
        try {
            System.out.println("Starting pet save process...");

            String type = getSelectedType();
            String name = nameField.getText().trim();
            System.out.println("Pet type: " + type + ", Name: " + name);

            if (!validateName()) {
                JOptionPane.showMessageDialog(this, "Please correct the name field.",
                        "Validation Error", JOptionPane.ERROR_MESSAGE);
                logActivity("Pet save failed: Name validation error.");
                return;
            }

            LocalDate dob;
            int age;
            try {
                String dobText = dobField.getText().trim();
                if (dobText.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Please enter Date of Birth.",
                            "Validation Error", JOptionPane.ERROR_MESSAGE);
                    logActivity("Pet save failed: Date of Birth not entered.");
                    return;
                }

                SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
                Date d = sdf.parse(dobText);
                dob = d.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                long ageYears = ChronoUnit.YEARS.between(dob, LocalDate.now());
                age = (int) ageYears;
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Invalid Date of Birth format. Please use MM/DD/YYYY.",
                        "Validation Error", JOptionPane.ERROR_MESSAGE);
                logActivity("Pet save failed: Invalid Date of Birth format.");
                return;
            }

            String breed = (String) breedCombo.getSelectedItem();
            if (breed == null || breed.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please select a breed.",
                        "Validation Error", JOptionPane.ERROR_MESSAGE);
                logActivity("Pet save failed: Breed not selected.");
                return;
            }

            String healthStatus = (String) healthCombo.getSelectedItem();
            boolean vaccinated = vaccCheck.isSelected();
            String notes = "";
            String id = PetManager.generateAutoId(type);

            Pet newPet;
            String extra = "";

            if (type.equals("Dog")) {
                extra = (String) sizeCombo.getSelectedItem();
                if (extra == null || extra.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Please select a size for the dog.",
                            "Validation Error", JOptionPane.ERROR_MESSAGE);
                    logActivity("Pet save failed: Dog size not selected.");
                    return;
                }
                newPet = new Dog(id, name, dob, age, breed, healthStatus, vaccinated, imagePath, notes, extra);
            } else if (type.equals("Cat")) {
                newPet = new Cat(id, name, dob, age, breed, healthStatus, vaccinated, imagePath, notes);
            } else if (type.equals("Bird")) {
                newPet = new Bird(id, name, dob, age, breed, healthStatus, vaccinated, imagePath, notes);
            } else if (type.equals("Rabbit")) {
                newPet = new Rabbit(id, name, dob, age, breed, healthStatus, vaccinated, imagePath, notes);
            } else if (type.equals("Fish")) {
                newPet = new Fish(id, name, dob, age, breed, healthStatus, vaccinated, imagePath, notes);
            } else {
                throw new IllegalArgumentException("Invalid pet type selected.");
            }

            if (PetManager.isDuplicate(newPet)) {
                JOptionPane.showMessageDialog(this, "A pet with the same name and type already exists.",
                        "Validation Error", JOptionPane.ERROR_MESSAGE);
                logActivity("Pet save failed: Duplicate pet detected (Name: " + name + ", Type: " + type + ").");
                return;
            }

            PetManager.addPet(newPet);
            System.out.println("Pet added successfully to PetManager");

            JOptionPane.showMessageDialog(this, "Pet Saved Successfully! ID: " + newPet.getPetId(),
                    "Success", JOptionPane.INFORMATION_MESSAGE);
            logActivity("New pet added: " + newPet.getName() + " (ID: " + newPet.getPetId() + ", Type: " + newPet.getType() + ").");

            try {
                JsonFileManager.savePetsToJson(PetManager.getAllPets());
                logActivity("Data automatically saved to JSON format.");
            } catch (IOException jsonEx) {
                logActivity("Warning: Could not auto-save to JSON: " + jsonEx.getMessage());
            }

            clearForm();

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving pet data: " + ex.getMessage(),
                    "Save Error", JOptionPane.ERROR_MESSAGE);
            logActivity("Pet save failed (IO Error): " + ex.getMessage());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "An unexpected error occurred: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            logActivity("Pet save failed (Unexpected Error): " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    public void refreshCounts() {
    }

    public void clearForm() {
        updateAutoId();
        dogRadio.setSelected(true);
        updateBreedOptions();
        nameField.setText("");

        // Set current date as default
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        dobField.setText(sdf.format(new Date()));

        updateAgeLabel();
        imagePath = "";
        imageLabel.setIcon(null);
        imageLabel.setText("<html><center>Image Preview</center></html>");
        vaccCheck.setSelected(false);
        healthCombo.setSelectedIndex(0);
        sizeCombo.setSelectedIndex(0);
        nameErrorLabel.setVisible(false);
        logActivity("Form cleared.");
    }

    private void logActivity(String message) {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        String timestamp = sdf.format(new Date());
        activityLogArea.append("[" + timestamp + "] " + message + "\n");
        activityLogArea.setCaretPosition(activityLogArea.getDocument().getLength());
    }
}

// =========================================================================
// VIEW PETS PANEL (UPDATED)
// =========================================================================

class ViewPetsPanel extends JPanel {
    private final Color PRIMARY_BRAND_BLUE = new Color(0, 94, 70);
    private final Font DETAIL_FONT = new Font("Monospaced", Font.PLAIN, 14);

    private JTable petsTable;
    private DefaultTableModel tableModel;
    private List<Pet> allPets;

    private JTextField searchNameField;
    private JComboBox<String> typeFilterComboBox;
    private JComboBox<String> statusFilterComboBox;

    private JLabel nameValueLabel;
    private JLabel speciesValueLabel;
    private JLabel ageValueLabel;
    private JLabel breedValueLabel;
    private JLabel healthValueLabel;
    private JLabel vaccinatedValueLabel;
    private JLabel statusValueLabel;
    private JLabel petImageLabel;

    private JButton deletePetButton;
    private JButton resetButton;

    public ViewPetsPanel() {
        setLayout(new BorderLayout(20, 20));
        setBackground(new Color(240, 240, 240));
        setBorder(new EmptyBorder(30, 30, 30, 30));

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setResizeWeight(0.7);
        splitPane.setDividerSize(10);
        splitPane.setOpaque(false);

        JPanel leftPanel = new JPanel(new BorderLayout(10, 10));
        leftPanel.setOpaque(false);

        JPanel searchFilterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        searchFilterPanel.setOpaque(false);
        searchFilterPanel.setBorder(BorderFactory.createTitledBorder("Search & Filters"));

        searchFilterPanel.add(new JLabel("Search Name:"));
        searchNameField = new JTextField(10);
        searchNameField.addActionListener(e -> filterAndRefreshTable());
        searchFilterPanel.add(searchNameField);

        searchFilterPanel.add(new JLabel("Type:"));
        typeFilterComboBox = new JComboBox<>(new String[]{"All Types", "Dog", "Cat", "Bird", "Rabbit", "Fish"});
        typeFilterComboBox.addActionListener(e -> filterAndRefreshTable());
        searchFilterPanel.add(typeFilterComboBox);

        searchFilterPanel.add(new JLabel("Status:"));
        // UPDATED: Only "Available" option in dropdown
        statusFilterComboBox = new JComboBox<>(new String[]{"Available"});
        statusFilterComboBox.setEnabled(false); // Locked to Available
        statusFilterComboBox.addActionListener(e -> filterAndRefreshTable());
        searchFilterPanel.add(statusFilterComboBox);

        JButton applyFiltersButton = new JButton("Apply Filters");
        applyFiltersButton.setBackground(PRIMARY_BRAND_BLUE);
        applyFiltersButton.setForeground(Color.WHITE);
        applyFiltersButton.setOpaque(true);
        applyFiltersButton.setBorderPainted(false);
        applyFiltersButton.setFocusPainted(false);
        applyFiltersButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        applyFiltersButton.addActionListener(e -> filterAndRefreshTable());
        searchFilterPanel.add(applyFiltersButton);

        leftPanel.add(searchFilterPanel, BorderLayout.NORTH);

        String[] columnNames = {"ID", "Name", "Type", "Breed", "Age", "Size", "Health", "Vac?", "Status", "Fee ($)"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        petsTable = new JTable(tableModel);
        petsTable.setRowHeight(25);
        petsTable.setFont(new Font("Arial", Font.PLAIN, 14));
        petsTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        petsTable.getTableHeader().setBackground(PRIMARY_BRAND_BLUE.brighter());
        petsTable.getTableHeader().setForeground(Color.WHITE);
        petsTable.setFillsViewportHeight(true);
        petsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(petsTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(PRIMARY_BRAND_BLUE, 2));
        leftPanel.add(scrollPane, BorderLayout.CENTER);

        JPanel bottomButtonsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        bottomButtonsPanel.setOpaque(false);

        deletePetButton = createActionButton("Delete Pet", new Color(220, 53, 69));
        deletePetButton.addActionListener(e -> deleteSelectedPet());
        bottomButtonsPanel.add(deletePetButton);

        resetButton = createActionButton("Reset Filters", new Color(0, 94, 70));
        resetButton.addActionListener(e -> resetFilters());
        bottomButtonsPanel.add(resetButton);


        leftPanel.add(bottomButtonsPanel, BorderLayout.SOUTH);

        splitPane.setLeftComponent(leftPanel);

        JPanel rightPanel = new JPanel(new BorderLayout(10, 10));
        rightPanel.setOpaque(false);
        rightPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(PRIMARY_BRAND_BLUE.darker(), 1),
                "Pet Details",
                TitledBorder.LEFT, TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 16), PRIMARY_BRAND_BLUE
        ));

        JPanel detailsContentPanel = new JPanel(new GridBagLayout());
        detailsContentPanel.setOpaque(false);
        detailsContentPanel.setBorder(new EmptyBorder(15, 15, 15, 15));

        GridBagConstraints detailsGbc = new GridBagConstraints();
        detailsGbc.insets = new Insets(5, 5, 5, 5);
        detailsGbc.fill = GridBagConstraints.HORIZONTAL;
        detailsGbc.anchor = GridBagConstraints.NORTHWEST;

        JPanel imageContainer = new JPanel(new BorderLayout());
        imageContainer.setOpaque(false);
        imageContainer.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(200, 200, 200), 1),
                new EmptyBorder(5, 5, 5, 5)
        ));
        imageContainer.setPreferredSize(new Dimension(250, 200));

        petImageLabel = new JLabel();
        petImageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        petImageLabel.setVerticalAlignment(SwingConstants.CENTER);
        petImageLabel.setOpaque(true);
        petImageLabel.setBackground(new Color(250, 250, 250));
        showDefaultImage();
        imageContainer.add(petImageLabel, BorderLayout.CENTER);

        detailsGbc.gridx = 0;
        detailsGbc.gridy = 0;
        detailsGbc.gridwidth = 2;
        detailsGbc.weightx = 1.0;
        detailsGbc.weighty = 0;
        detailsContentPanel.add(imageContainer, detailsGbc);

        JPanel infoPanel = new JPanel(new GridBagLayout());
        infoPanel.setOpaque(false);
        infoPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));

        GridBagConstraints infoGbc = new GridBagConstraints();
        infoGbc.anchor = GridBagConstraints.WEST;
        infoGbc.insets = new Insets(2, 5, 2, 5);

        int row = 0;
        infoGbc.gridx = 0; infoGbc.gridy = row; infoGbc.weightx = 0; infoGbc.fill = GridBagConstraints.NONE;
        infoPanel.add(createAlignedLabel("Name:"), infoGbc);
        infoGbc.gridx = 1; infoGbc.weightx = 1; infoGbc.fill = GridBagConstraints.HORIZONTAL;
        nameValueLabel = createValueLabel("");
        infoPanel.add(nameValueLabel, infoGbc);

        row++; infoGbc.gridx = 0; infoGbc.gridy = row; infoGbc.weightx = 0; infoGbc.fill = GridBagConstraints.NONE;
        infoPanel.add(createAlignedLabel("Species:"), infoGbc);
        infoGbc.gridx = 1; infoGbc.weightx = 1; infoGbc.fill = GridBagConstraints.HORIZONTAL;
        speciesValueLabel = createValueLabel("");
        infoPanel.add(speciesValueLabel, infoGbc);

        row++; infoGbc.gridx = 0; infoGbc.gridy = row; infoGbc.weightx = 0; infoGbc.fill = GridBagConstraints.NONE;
        infoPanel.add(createAlignedLabel("Age:"), infoGbc);
        infoGbc.gridx = 1; infoGbc.weightx = 1; infoGbc.fill = GridBagConstraints.HORIZONTAL;
        ageValueLabel = createValueLabel("");
        infoPanel.add(ageValueLabel, infoGbc);

        row++; infoGbc.gridx = 0; infoGbc.gridy = row; infoGbc.weightx = 0; infoGbc.fill = GridBagConstraints.NONE;
        infoPanel.add(createAlignedLabel("Breed:"), infoGbc);
        infoGbc.gridx = 1; infoGbc.weightx = 1; infoGbc.fill = GridBagConstraints.HORIZONTAL;
        breedValueLabel = createValueLabel("");
        infoPanel.add(breedValueLabel, infoGbc);

        row++; infoGbc.gridx = 0; infoGbc.gridy = row; infoGbc.weightx = 0; infoGbc.fill = GridBagConstraints.NONE;
        infoPanel.add(createAlignedLabel("Health:"), infoGbc);
        infoGbc.gridx = 1; infoGbc.weightx = 1; infoGbc.fill = GridBagConstraints.HORIZONTAL;
        healthValueLabel = createValueLabel("");
        infoPanel.add(healthValueLabel, infoGbc);

        row++; infoGbc.gridx = 0; infoGbc.gridy = row; infoGbc.weightx = 0; infoGbc.fill = GridBagConstraints.NONE;
        infoPanel.add(createAlignedLabel("Vaccinated:"), infoGbc);
        infoGbc.gridx = 1; infoGbc.weightx = 1; infoGbc.fill = GridBagConstraints.HORIZONTAL;
        vaccinatedValueLabel = createValueLabel("");
        infoPanel.add(vaccinatedValueLabel, infoGbc);

        row++; infoGbc.gridx = 0; infoGbc.gridy = row; infoGbc.weightx = 0; infoGbc.fill = GridBagConstraints.NONE;
        infoPanel.add(createAlignedLabel("Status:"), infoGbc);
        infoGbc.gridx = 1; infoGbc.weightx = 1; infoGbc.fill = GridBagConstraints.HORIZONTAL;
        statusValueLabel = createValueLabel("");
        infoPanel.add(statusValueLabel, infoGbc);

        detailsGbc.gridx = 0;
        detailsGbc.gridy = 1;
        detailsGbc.gridwidth = 2;
        detailsGbc.weightx = 1.0;
        detailsGbc.weighty = 1.0;
        detailsGbc.fill = GridBagConstraints.BOTH;
        detailsContentPanel.add(infoPanel, detailsGbc);

        rightPanel.add(detailsContentPanel, BorderLayout.CENTER);
        splitPane.setRightComponent(rightPanel);

        add(splitPane, BorderLayout.CENTER);

        searchNameField.addActionListener(e -> filterAndRefreshTable());
        typeFilterComboBox.addActionListener(e -> filterAndRefreshTable());
        statusFilterComboBox.addActionListener(e -> filterAndRefreshTable());

        applyFiltersButton.addActionListener(e -> filterAndRefreshTable());

        resetButton.addActionListener(e -> resetFilters());

        deletePetButton.addActionListener(e -> deleteSelectedPet());

        petsTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                displayPetDetails();
            }
        });

        loadAndDisplayPets();
    }

    private JLabel createAlignedLabel(String text) {
        JLabel label = new JLabel(String.format("%-15s", text));
        label.setFont(DETAIL_FONT);
        label.setForeground(new Color(51, 51, 51));
        return label;
    }

    private JLabel createValueLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(DETAIL_FONT);
        label.setForeground(new Color(0, 94, 70));
        return label;
    }

    private JButton createActionButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(bgColor);
        button.setOpaque(true);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        return button;
    }

    public void loadAndDisplayPets() {
        System.out.println("Loading pets data...");
        PetManager.loadAllPets();
        allPets = PetManager.getAllPets();
        System.out.println("Total pets loaded: " + allPets.size());
        filterAndRefreshTable();
    }

    // NEW: Helper method to calculate detailed age string from DOB
    private String calculateDetailedAge(LocalDate dob) {
        if (dob == null) return "N/A";
        LocalDate now = LocalDate.now();
        if (dob.isAfter(now)) return "N/A";

        long years = ChronoUnit.YEARS.between(dob, now);
        long months = ChronoUnit.MONTHS.between(dob, now);
        long days = ChronoUnit.DAYS.between(dob, now);

        if (years > 0) return years + " Year" + (years > 1 ? "s" : "");
        if (months > 0) return months + " Month" + (months > 1 ? "s" : "");
        return days + " Day" + (days != 1 ? "s" : "");
    }

    private void filterAndRefreshTable() {
        tableModel.setRowCount(0);

        String searchTerm = searchNameField.getText().toLowerCase();
        String selectedType = (String) typeFilterComboBox.getSelectedItem();

        for (Pet pet : allPets) {
            boolean matchesSearch = pet.getName().toLowerCase().contains(searchTerm) ||
                    pet.getBreed().toLowerCase().contains(searchTerm) ||
                    pet.getPetId().toLowerCase().contains(searchTerm);
            boolean matchesType = selectedType.equals("All Types") || pet.getType().equalsIgnoreCase(selectedType);

            // UPDATED: Strict check for Available status only
            boolean matchesStatus = pet.getStatus().equalsIgnoreCase("Available");

            if (matchesSearch && matchesType && matchesStatus) {
                String size = "N/A";
                if (pet instanceof Dog) {
                    size = ((Dog) pet).getSize();
                }

                // UPDATED: Use calculateDetailedAge instead of pet.getAge()
                String detailedAge = calculateDetailedAge(pet.getDob());

                Object[] row = {
                        pet.getPetId(),
                        pet.getName(),
                        pet.getType(),
                        pet.getBreed(),
                        detailedAge, // Show calculated age string
                        size,
                        pet.getHealthStatus(),
                        pet.isVaccinated() ? "Yes" : "No",
                        pet.getStatus(),
                        getDummyFee(pet.getType())
                };
                tableModel.addRow(row);
            }
        }
        System.out.println("Displaying " + tableModel.getRowCount() + " pets in table");
        clearPetDetails();
    }

    private double getDummyFee(String petType) {
        switch (petType) {
            case "Dog": return 150.0;
            case "Cat": return 80.0;
            case "Bird": return 50.0;
            case "Rabbit": return 40.0;
            case "Fish": return 20.0;
            default: return 0.0;
        }
    }

    private void resetFilters() {
        searchNameField.setText("");
        typeFilterComboBox.setSelectedItem("All Types");
        // Status reset not needed as it is locked to Available
        filterAndRefreshTable();
    }

    private void displayPetDetails() {
        int selectedRow = petsTable.getSelectedRow();
        if (selectedRow == -1) {
            clearPetDetails();
            return;
        }

        String petId = (String) petsTable.getValueAt(selectedRow, 0);
        Pet selectedPet = PetManager.getPetById(petId);

        if (selectedPet != null) {
            nameValueLabel.setText(selectedPet.getName());
            speciesValueLabel.setText(selectedPet.getType());

            // UPDATED: Use calculateDetailedAge for details panel too
            ageValueLabel.setText(calculateDetailedAge(selectedPet.getDob()));

            breedValueLabel.setText(selectedPet.getBreed());
            healthValueLabel.setText(selectedPet.getHealthStatus());
            vaccinatedValueLabel.setText(selectedPet.isVaccinated() ? "Yes" : "No");
            statusValueLabel.setText(selectedPet.getStatus());

            loadPetImage(selectedPet);

            SwingUtilities.invokeLater(() -> {
                if (SwingUtilities.getWindowAncestor(this) != null) {
                    SwingUtilities.getWindowAncestor(this).revalidate();
                    SwingUtilities.getWindowAncestor(this).repaint();
                }
            });

        } else {
            clearPetDetails();
        }
    }

    private void loadPetImage(Pet pet) {
        if (pet.getImagePath() != null && !pet.getImagePath().isEmpty()) {
            try {
                ImageIcon icon = null;
                String imagePath = pet.getImagePath();

                File imgFile = new File(imagePath);
                if (imgFile.exists() && imgFile.isFile()) {
                    icon = new ImageIcon(ImageIO.read(imgFile));
                } else {
                    URL imgURL = getClass().getResource(imagePath);
                    if (imgURL == null && imagePath.startsWith("/")) {
                        imgURL = getClass().getResource(imagePath.substring(1));
                    }
                    if (imgURL != null) {
                        icon = new ImageIcon(imgURL);
                    }
                }

                if (icon != null && icon.getIconWidth() > 0) {
                    Image scaledImage = icon.getImage().getScaledInstance(240, 180, Image.SCALE_SMOOTH);
                    petImageLabel.setIcon(new ImageIcon(scaledImage));
                    petImageLabel.setText("");
                } else {
                    showDefaultImage();
                }
            } catch (Exception ex) {
                System.err.println("Error loading image for " + pet.getName() + ": " + ex.getMessage());
                showDefaultImage();
            }
        } else {
            showDefaultImage();
        }
        petImageLabel.revalidate();
        petImageLabel.repaint();
    }

    private void showDefaultImage() {
        petImageLabel.setIcon(null);
        petImageLabel.setText("<html><div style='text-align:center;color:gray;'>"
                + "No Image<br>Available"
                + "</div></html>");
        petImageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        petImageLabel.setVerticalAlignment(SwingConstants.CENTER);
    }

    private void clearPetDetails() {
        nameValueLabel.setText("");
        speciesValueLabel.setText("");
        ageValueLabel.setText("");
        breedValueLabel.setText("");
        healthValueLabel.setText("");
        vaccinatedValueLabel.setText("");
        statusValueLabel.setText("");
        showDefaultImage();
        SwingUtilities.invokeLater(() -> {
            if (SwingUtilities.getWindowAncestor(this) != null) {
                SwingUtilities.getWindowAncestor(this).revalidate();
                SwingUtilities.getWindowAncestor(this).repaint();
            }
        });
    }

    private void deleteSelectedPet() {
        int selectedRow = petsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a pet to delete.", "No Pet Selected", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String petIdToDelete = (String) petsTable.getValueAt(selectedRow, 0);
        String petNameToDelete = (String) petsTable.getValueAt(selectedRow, 1);

        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete " + petNameToDelete + " (ID: " + petIdToDelete + ")?\n" +
                        "This action cannot be undone.", "Confirm Deletion", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            if (PetManager.deletePet(petIdToDelete)) {
                JOptionPane.showMessageDialog(this, petNameToDelete + " has been deleted successfully.", "Deletion Successful", JOptionPane.INFORMATION_MESSAGE);
                loadAndDisplayPets();
            } else {
                JOptionPane.showMessageDialog(this, "Error deleting " + petNameToDelete + ".", "Deletion Failed", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public void navigateToAddPet() {
        JFrame topFrame = (JFrame) SwingUtilities.getWindowAncestor(this);
        if (topFrame instanceof HomePage) {
            ((HomePage) topFrame).displayAddPetsSection();
        }
    }
}

// =========================================================================
// MAIN HOMEPAGE CLASS
// =========================================================================

public class HomePage extends JFrame implements ActionListener {
    private JPanel headerPanel;
    private JPanel subNavPanel;
    private HeroPanel heroPanel;
    private JPanel mainContentPanel;

    private TestimonialsSectionPanel testimonialsSectionPanel;
    private AdoptionRecordsPanel adoptionRecordsPanel;
    private AddPetPanel addPetPanel;
    private ViewPetsPanel viewPetsPanel;

    private final Color PRIMARY_BRAND_BLUE = new Color(0, 94, 70);
    private final Color PRIMARY_BRAND_BLUE_DARK = new Color(31, 31, 31);
    private final Color ACCENT_ORANGE = new Color(154, 103, 53);
    private final Color TEXT_WHITE = Color.WHITE;

    private final Font LOGO_FONT = new Font("Bodoni MT Black", Font.BOLD, 42);
    private final Font SUB_NAV_ITEM_FONT = new Font("Times New Roman", Font.PLAIN, 20);
    private final Font HERO_TITLE_FONT = new Font("Broadway", Font.BOLD, 50);
    private final Font HERO_SUBTITLE_FONT = new Font("Times New Roman", Font.PLAIN, 26);
    private final Font VIEW_PETS_BUTTON_FONT = new Font("Calibri Light (Headings)", Font.BOLD, 22);

    public HomePage() {
        setTitle("Pet Palace - Find your new best friend");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(Color.DARK_GRAY);

        // Print current directory for debugging
        System.out.println("Current directory: " + System.getProperty("user.dir"));
        System.out.println("JSON file path: " + new File("pets_data.json").getAbsolutePath());

        JPanel northContainer = new JPanel();
        northContainer.setLayout(new BoxLayout(northContainer, BoxLayout.Y_AXIS));

        headerPanel = new JPanel();
        headerPanel.setOpaque(true);
        headerPanel.setBackground(PRIMARY_BRAND_BLUE);
        headerPanel.setPreferredSize(new Dimension(getWidth(), 80));
        headerPanel.setLayout(new BorderLayout());
        headerPanel.setBorder(new EmptyBorder(0, 40, 0, 40));

        JPanel logoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        logoPanel.setOpaque(false);
        JLabel home2HeartLogo = new JLabel("Pet Palace");
        home2HeartLogo.setFont(LOGO_FONT);
        home2HeartLogo.setForeground(TEXT_WHITE);

        try {
            URL pawIconURL = getClass().getResource("/icons/logo.png");
            if (pawIconURL != null) {
                ImageIcon originalIcon = new ImageIcon(pawIconURL);
                Image scaledImage = originalIcon.getImage().getScaledInstance(90, 75, Image.SCALE_SMOOTH);
                home2HeartLogo.setIcon(new ImageIcon(scaledImage));
                home2HeartLogo.setIconTextGap(8);
            } else {
                System.err.println("Error: logo.png not found in classpath (/icons/). Please place it there.");
            }
        } catch (Exception ex) {
            System.err.println("Error loading logo.png icon: " + ex.getMessage());
        }

        JPanel logoTextContainer = new JPanel();
        logoTextContainer.setOpaque(false);
        logoTextContainer.setLayout(new BoxLayout(logoTextContainer, BoxLayout.Y_AXIS));

        logoTextContainer.add(Box.createVerticalStrut(8));
        home2HeartLogo.setAlignmentX(Component.LEFT_ALIGNMENT);
        logoTextContainer.add(home2HeartLogo);

        logoPanel.add(logoTextContainer);
        headerPanel.add(logoPanel, BorderLayout.WEST);

        JPanel rightHeaderPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 15));
        rightHeaderPanel.setOpaque(false);

        try {
            URL heartIconURL = getClass().getResource("/icons/heart_icon.png");
            if (heartIconURL != null) {
                ImageIcon originalIcon = new ImageIcon(heartIconURL);
                Image scaledImage = originalIcon.getImage().getScaledInstance(50, 48, Image.SCALE_SMOOTH);
                JLabel heartLabel = new JLabel(new ImageIcon(scaledImage));
                heartLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
                heartLabel.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        JOptionPane.showMessageDialog(null, "Favorites clicked!");
                    }
                });
                rightHeaderPanel.add(heartLabel);
            } else {
                System.err.println("Error: heart_icon.png not found in classpath (/icons/). Please place it there.");
            }
        } catch (Exception ex) {
            System.err.println("Error loading heart_icon: " + ex.getMessage());
        }

        headerPanel.add(rightHeaderPanel, BorderLayout.EAST);
        northContainer.add(headerPanel);

        subNavPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 50, 18));
        subNavPanel.setBackground(PRIMARY_BRAND_BLUE_DARK);
        subNavPanel.setPreferredSize(new Dimension(getWidth(), 70));

        String[] subNavItems = {"Home", "Add Pets", "View Pets", "Adoption Records", "Testimonials"};
        for (String item : subNavItems) {
            JButton navButton = new JButton(item);
            navButton.setFont(SUB_NAV_ITEM_FONT);
            navButton.setForeground(TEXT_WHITE);
            navButton.setOpaque(false);
            navButton.setContentAreaFilled(false);
            navButton.setBorderPainted(false);
            navButton.setFocusPainted(false);
            navButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
            navButton.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    navButton.setForeground(ACCENT_ORANGE);
                    navButton.setBorder(BorderFactory.createMatteBorder(0, 0, 3, 0, ACCENT_ORANGE));
                }
                @Override
                public void mouseExited(MouseEvent e) {
                    navButton.setForeground(TEXT_WHITE);
                    navButton.setBorder(BorderFactory.createEmptyBorder());
                }
            });
            navButton.addActionListener(e -> {
                if (item.equals("Home")) {
                    displayHeroSection();
                } else if (item.equals("Add Pets")) {
                    displayAddPetsSection();
                } else if (item.equals("View Pets")) {
                    displayViewPetsSection();
                }
                else if (item.equals("Testimonials")) {
                    displayTestimonialsSection();
                } else if (item.equals("Adoption Records")) {
                    displayAdoptionRecordsSection();
                }
                else {
                    JOptionPane.showMessageDialog(this, item + " clicked!");
                }
            });
            subNavPanel.add(navButton);
        }
        northContainer.add(subNavPanel);
        add(northContainer, BorderLayout.NORTH);

        mainContentPanel = new JPanel(new BorderLayout());
        add(mainContentPanel, BorderLayout.CENTER);

        heroPanel = new HeroPanel("/images/hero_bg.jpg");
        heroPanel.setOpaque(true);
        setupHeroSection();
        displayHeroSection();

        adoptionRecordsPanel = new AdoptionRecordsPanel();
        addPetPanel = new AddPetPanel();
        viewPetsPanel = new ViewPetsPanel();

        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setVisible(true);
    }

    private void setupHeroSection() {
        heroPanel.removeAll();

        GridBagConstraints gbc_hero = new GridBagConstraints();
        gbc_hero.gridx = 0;
        gbc_hero.weightx = 1.0;
        gbc_hero.anchor = GridBagConstraints.CENTER;

        gbc_hero.gridy = 0;
        gbc_hero.insets = new Insets(100, 50, 15, 50);
        JLabel heroTitle = new JLabel("<html><div style='text-align: center;'>Your Journey to a Loving Pet Starts Here</div></html>");
        heroTitle.setFont(HERO_TITLE_FONT);
        heroTitle.setForeground(TEXT_WHITE);
        heroTitle.setHorizontalAlignment(SwingConstants.CENTER);
        heroPanel.add(heroTitle, gbc_hero);

        gbc_hero.gridy = 1;
        gbc_hero.insets = new Insets(0, 50, 60, 50);
        JLabel heroSubtitle = new JLabel("<html><div style='text-align: center;'>Manage pet records and adoption processes with ease.</div></html>");
        heroSubtitle.setFont(HERO_SUBTITLE_FONT);
        heroSubtitle.setForeground(TEXT_WHITE.brighter());
        heroSubtitle.setHorizontalAlignment(SwingConstants.CENTER);
        heroPanel.add(heroSubtitle, gbc_hero);

        gbc_hero.gridy = 2;
        gbc_hero.insets = new Insets(0, 50, 120, 50);
        gbc_hero.fill = GridBagConstraints.NONE;
        gbc_hero.weighty = 1.0;
        gbc_hero.anchor = GridBagConstraints.NORTH;

        JButton viewPetsButton = new JButton("View Available Pets");
        viewPetsButton.setFont(VIEW_PETS_BUTTON_FONT);
        viewPetsButton.setForeground(TEXT_WHITE);
        viewPetsButton.setBackground(ACCENT_ORANGE);
        viewPetsButton.setOpaque(true);
        viewPetsButton.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(ACCENT_ORANGE.darker(), 2, true),
                new EmptyBorder(15, 40, 15, 40)
        ));
        viewPetsButton.setFocusPainted(false);
        viewPetsButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        viewPetsButton.addActionListener(e -> displayViewPetsSection());

        viewPetsButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                viewPetsButton.setBackground(ACCENT_ORANGE.darker());
                viewPetsButton.setBorder(BorderFactory.createCompoundBorder(
                        new LineBorder(ACCENT_ORANGE.darker().darker(), 3, true),
                        new EmptyBorder(15, 40, 15, 40)
                ));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                viewPetsButton.setBackground(ACCENT_ORANGE);
                viewPetsButton.setBorder(BorderFactory.createCompoundBorder(
                        new LineBorder(ACCENT_ORANGE.darker(), 2, true),
                        new EmptyBorder(15, 40, 15, 40)
                ));
            }
        });
        heroPanel.add(viewPetsButton, gbc_hero);
    }

    public void displayHeroSection() {
        mainContentPanel.removeAll();
        mainContentPanel.add(heroPanel, BorderLayout.CENTER);
        mainContentPanel.revalidate();
        mainContentPanel.repaint();
    }

    public void displayAddPetsSection() {
        mainContentPanel.removeAll();
        mainContentPanel.add(addPetPanel, BorderLayout.CENTER);
        addPetPanel.clearForm();
        mainContentPanel.revalidate();
        mainContentPanel.repaint();
    }

    public void displayViewPetsSection() {
        mainContentPanel.removeAll();
        mainContentPanel.add(viewPetsPanel, BorderLayout.CENTER);
        viewPetsPanel.loadAndDisplayPets();
        mainContentPanel.revalidate();
        mainContentPanel.repaint();
    }

    private void displayTestimonialsSection() {
        if (testimonialsSectionPanel == null) {
            List<Testimonial> testimonials = new ArrayList<>();
            testimonials.add(new Testimonial("Zaviyar Khan", "My family and I adopted Fish, a Gold Fish, through Pet Palace, and it was the best decision ever! The process was smooth, and Buddy is now a cherished member of our family. Highly recommend!", "/images/profile1.jpg", "/images/testimonial_pet1.jpg"));
            testimonials.add(new Testimonial("Aizel Fatima", "I was looking for a cat for months, and Pet Palace helped me find Luna. She's a sweet tabby, and I can't imagine life without her. Thank you for connecting us!", "/images/profile2.jpg", "/images/testimonial_pet2.jpg"));
            testimonials.add(new Testimonial("Armaghan.M", "We adopted our lovely parrot, Coco, through Pet Palace. The entire experience was fantastic, and Coco brings so much laughter to our home. Five stars!", "/images/profile3.jpg", "/images/testimonial_pet3.jpg"));
            testimonials.add(new Testimonial("Vishal Shah", "Finding my German Shepherd, Rocky, was easy and enjoyable thanks to Pet Palace. He's a wonderful companion, and I'm grateful for this service.", "/images/profile4.jpg", "/images/testimonial_pet4.jpg"));
            testimonials.add(new Testimonial("Aliyaar", "I volunteered with Pet Palace before adopting my two kittens. Their dedication is inspiring, and I witnessed first-hand the care they provide.", "/images/profile5.jpg", "/images/testimonial_pet5.jpg"));
            testimonials.add(new Testimonial("Syeda Miral", "The application process was straightforward, and the team was very helpful. Our new dog, Bella, has brought so much joy into our lives. Thanks, Pet Palace!", "/images/profile6.jpg", "/images/testimonial_pet6.jpg"));
            testimonials.add(new Testimonial("Shahram Khan", "Pet Palace provided excellent support throughout the adoption of my new Chicks. They truly care about the animals and ensure they find loving homes.", "/images/profile7.jpg", "/images/testimonial_pet7.jpg"));
            testimonials.add(new Testimonial("Mifra Fatima", "My new Cat, Squeaky, is the cutest little guy. Pet Palace made the adoption process simple and educational. Highly recommended for small pet adoptions too!", "/images/profile8.jpg", "/images/testimonial_pet8.jpg"));
            testimonials.add(new Testimonial("Burhan Ansari", "I never thought I'd adopt a rabbit, but Blossom stole my heart. Pet Palace helped me understand rabbit care, and I'm so glad I found them.", "/images/profile9.jpg", "/images/testimonial_pet9.jpg"));

            testimonialsSectionPanel = new TestimonialsSectionPanel(testimonials);
        }

        mainContentPanel.removeAll();
        mainContentPanel.add(testimonialsSectionPanel, BorderLayout.CENTER);
        mainContentPanel.revalidate();
        mainContentPanel.repaint();
    }

    private void displayAdoptionRecordsSection() {
        mainContentPanel.removeAll();
        mainContentPanel.add(adoptionRecordsPanel, BorderLayout.CENTER);
        adoptionRecordsPanel.loadAndDisplayRecords();
        mainContentPanel.revalidate();
        mainContentPanel.repaint();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
    }

    public static void main(String[] args) {
        System.out.println("Starting Pet Palace Application...");
        System.out.println("Current directory: " + System.getProperty("user.dir"));
        System.out.println("JSON file path: " + new File("pets_data.json").getAbsolutePath());

        SwingUtilities.invokeLater(HomePage::new);
    }
}
